import logging
logging.basicConfig(level=logging.INFO)
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np


#ferramentas = ["vader"]

base_path = "C:/Users/junior/Google Drive/_Mestrado/SEAN/Dissertacao_Celso/resources/datasets/exp2/"
records = base_path+"grafico_novos_casos_e_mortes_tempo.csv"


df = pd.read_csv(records)

print(df.head(3))

df1 = df[["data","casos_novos"]]
df2 = df[["data","obitos_novos"]]
df3 = df[["data","tweet_base"]]
df1.columns = ["data", "qtd"]
df2.columns = ["data", "qtd"]
df3.columns = ["data", "qtd"]
df1["tipo"] = "Novos Casos"
df2["tipo"] = "Novos Óbitos"
df3["tipo"] = "Tweet Base"

print(df1)
print(df2)
print(df3)

df_union_all= pd.concat([df1, df2, df3])

print(df_union_all.head(100))


fig = px.line(df_union_all, x="data", y="qtd", height=400, width=800,
              labels={'data': 'Período', 'qtd':'Quantidade', 'tipo':''}
              , color='tipo', log_y=True)
fig.update_traces(mode='markers+lines')
fig.update_layout(title_text='Calculated mean of polarity over the period', title_x=0.5,
                  legend=dict(
                      x=0.81,
                      y=0.995,
                      traceorder="normal")
                  )
fig.update_xaxes(range=[df['data'].min(), df['data'].max()])
fig.update_xaxes(
    #tickangle=45,
    tickvals =['2021-01-01','2021-02-01','2021-03-01','2021-04-01','2021-05-01','2021-06-01','2021-07-01','2021-08-01','2021-09-01','2021-10-01','2021-11-01','2021-12-01'],
    ticktext =['Jan<br>2021', 'Fev<br>', 'Mar<br>', 'Abr<br>', 'Mai<br>', 'Jun<br>', 'Jul<br>', 'Ago<br>', 'Set<br>', 'Out<br>', 'Nov<br>', 'Dez<br>2021']

                  )
fig.show()
