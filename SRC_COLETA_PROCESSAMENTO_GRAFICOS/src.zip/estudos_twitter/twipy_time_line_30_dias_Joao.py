# ##########################################################
# Tweets - User Timeline API
# Recuperar tweets e retweets de um usuário
# Referências:
# https://docs.tweepy.org/en/latest/api.html#tweepy.API.user_timeline
# https://developer.twitter.com/en/docs/twitter-api/v1/tweets/timelines/api-reference/get-statuses-user_timeline
# ##########################################################
import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] - %(message)s',
    filename='twipy_time_line_30_dias_Joao.log')


import twipyUtil as util
import dbUtil as dbUtil
import tweepy as tw
import time
import pandas as pd
import sys as sys
from datetime import datetime
tw.debug(False)



#print("User Current Version:-", sys.version)
#sys.exit()



def get_tweet_date(tid):
    offset = 1288834974657
    tstamp = (tid >> 22) + offset
    utcdttime = datetime.utcfromtimestamp(tstamp/1000)
    #print(str(tid) + " : " + str(tstamp) + " => " + str(utcdttime))
    return utcdttime.replace(hour=0, minute=0, second=0, microsecond=0)

def getBeforeFromUserTimeLine(api, user_screen_name, tweet_id_ref, qtd_days_before):
    tweets = []

    base_date = get_tweet_date(int(tweet_id_ref))
    try:
        for page in tw.Cursor(api.user_timeline
                , screen_name=user_screen_name
                , count=200  # Qtd de tweets retornados por página (default:20, maximo: 200)
                , skip_status=True
             # , exclude_replies = True # Inlcuir respostas ?
                , include_rts=True  # Incluir retweets ?
                , tweet_mode="extended"
                , since_id=None
                , max_id=tweet_id_ref).pages():

            '''
             Como os itens da página são ordenados descrescentemente, então verifico o último ítem(o mais antigo) 
             se ele for menor que 30(qtd_days_before) dias então eu adiciono a página inteira.
             senão, verifico item por item adicionando somente os com diferença menor que 30 dias. 
             Quando encontrar o primeiro > que 30 dias encerro
             '''
            last_item_date = get_tweet_date(page[-1].id) # o último ítem da página
            dias = (base_date - last_item_date).days # diferença em dias entre o tweet de referencia e o último recuperado na página

            if dias <= qtd_days_before:
                tweets.extend(page);
            else:
                for t in page:
                    item_date = get_tweet_date(t.id)
                    dias = (base_date - item_date).days

                    if dias <= qtd_days_before:
                        tweets.extend([t]);
                    else:
                        return tweets;

    except Exception as e:
        logging.info("Erro!! {} **************************************************************".format(str(e)))

    return tweets

def getAfterFromUserTimeLine(api, user_screen_name, tweet_id_ref, qtd_days_after):
    tweets = []

    base_date = get_tweet_date(int(tweet_id_ref))
    try:
        for page in tw.Cursor(api.user_timeline
                , screen_name=user_screen_name
                , count=200  # Qtd de tweets retornados por página (default:20, maximo: 200)
                , skip_status=True
             # , exclude_replies = True # Inlcuir respostas ?
                , include_rts=True  # Incluir retweets ?
                , tweet_mode="extended"
                , since_id= tweet_id_ref
                , max_id=None).pages():

            '''
             Como os itens da página são ordenados descrescentemente, então verifico o primeiro ítem(o mais recente) 
             se ele for menor que 30(qtd_days_after) dias então eu adiciono a página inteira.
             senão, verifico item por item adicionando somente os com diferença menor que 30 dias. 
             Quando encontrar o primeiro > que 30 dias encerro 
             '''
            first_item_date = get_tweet_date(page[-1].id) # o último ítem da página

            print(base_date)
            print(first_item_date)

            dias = (first_item_date - base_date).days # diferença em dias entre o tweet de referencia e o último recuperado na página

            print(dias)

            if dias > qtd_days_after:
                continue;
            else:
                for t in page:
                    item_date = get_tweet_date(t.id)
                    dias = (item_date - base_date).days

                    if dias > qtd_days_after:
                        continue;
                    else:
                        tweets.extend([t]);

    except Exception as e:
        logging.info("Erro!! {} **************************************************************".format(str(e)))

    return tweets

base_path = "C:/Users/junior/Google Drive/_Mestrado/SEAN/Dissertacao_Celso/resources/datasets/"
dataset_usuarios_unicos_path = base_path+"usuarios_unicos_importar_timeline_4.csv"

df = pd.read_csv(dataset_usuarios_unicos_path)

user_screen_names = df[["origem", "primeiro_tweet_id", "ultimo_tweet_id", "primeiro_tweet_data","ultimo_tweet_data"]]
user_screen_names.sort_values(by=['primeiro_tweet_data'], inplace=True, ascending=False)


iniciado = True
#iniciar_em = "narabolosbelem"

api = util.get_tweepy_api_conected("_Joao")

for index, row in user_screen_names.iterrows():

    if (iniciado == False and row['origem'] != iniciar_em):
        continue
    else:
        iniciado = True

    try:
        since_id_antes = None
        tweet_ref = row['primeiro_tweet_id']
        qtd_dias_antes = 60
        qtd_dias_Depois = 120
        logging.info("-----------------------------------------------------------------------------------------")
        logging.info("Processando DataFrameIndex:[{}], autor:[{}]".format(index, row['origem']))
        logging.info("primeiro_tweet_id:[{}], primeiro_tweet_data:[{}]".format(row['primeiro_tweet_id'],row['primeiro_tweet_data']))
        logging.info("-----------------------------------------------------------------------------------------")

        # Coletando tweets antes do fato ---------------------------
        tweets_antes = getBeforeFromUserTimeLine(api, row['origem'], tweet_ref, qtd_dias_antes)
        logging.info("tweets_antes: {}".format(len(tweets_antes)))
        tweet_details_antes = util.parse_tweet_to_array(tweets_antes)

        # Remove o tweet de referencia do array de tweets anteriores para gravalo separadamente
        tweet_details_ref = None
        if int(tweet_details_antes[0]['id']) == tweet_ref:
            tweet_details_ref = tweet_details_antes[0]
            tweet_details_antes.remove(tweet_details_antes[0])

        dbUtil.addToDatabase(tweet_details_antes, 'dataset_tweets_base_2021_timeline', row['origem'], 'A');
        dbUtil.addToDatabase([tweet_details_ref], 'dataset_tweets_base_2021_timeline', row['origem'], 'B'); # B: Tweet base

    # Coletando tweets depois do fato ---------------------------
        tweets_depois = getAfterFromUserTimeLine(api, row['origem'], tweet_ref, qtd_dias_Depois)
        logging.info("tweets_depois: {}".format(len(tweets_depois)))
        tweet_details_depois = util.parse_tweet_to_array(tweets_depois)
                          # (tweet_details       , table_name                         , search_words, flag, isInsertOrReplace=False):
        dbUtil.addToDatabase(tweet_details_depois, 'dataset_tweets_base_2021_timeline', row['origem'], 'D');


    except Exception as e:
        dbUtil.update_erro_carga_time_line("dataset_tweets_base_2021", row['origem'], type(e).__name__)
        logging.info("Erro!! {} **************************************************************".format(str(e)))




