import logging
logging.basicConfig(level=logging.INFO)
import pandas as pd
import plotly.express as px

base_path = "C:/Users/junior/Documents/jupterNotebooks/BERT/resources/datasets/"
records = base_path+"tweets_grafico_likes.csv"

df = pd.read_csv(records)

#Sugestão sean (juntar as 3 categorias em um único gráfico)
fig = px.line(df, x="data", y="avg_curtidas", color="sent_vader_categ",
              color_discrete_map={"POS": "blue", "NEG": "red","NEU":  "silver"},
                labels={"sent_vader_categ": "Sentiment Categories", 'avg_curtidas':'Avg Likes', 'data':'Dates'  },
                height=400, width=800
              )
fig.update_layout({'plot_bgcolor': 'rgba(0, 0, 0, 0)','paper_bgcolor': 'rgba(0, 0, 0, 0)'})
fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor='gray')
fig.update_layout(
    title='Avg Likes over the period',
    title_x=0.5,
    width=900,
    height=500
)

fig.show()


fig = px.line(df, x="data", y="avg_retweets", color="sent_vader_categ",
              color_discrete_map={"POS": "blue", "NEG": "red","NEU":  "silver"},
                labels={"sent_vader_categ": "Sentiment Categories", 'avg_retweets':'Avg Retweets', 'data':'Dates'  },
                height=400, width=800
              )
fig.update_layout({'plot_bgcolor': 'rgba(0, 0, 0, 0)','paper_bgcolor': 'rgba(0, 0, 0, 0)'})
fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor='gray')
fig.update_layout(
    title='Avg Retweets over the period',
    title_x=0.5,
    width=900,
    height=500
)
fig.show()


df = df[df['sent_vader_categ'] == 'NEG']

fig = px.bar(df, x='data', y='avg_curtidas',
             color='avg_curtidas',
             #facet_row="sent_vader_categ",
             labels={'data':'Dates',
                     'avg_curtidas':'Avg Likes'},
             height=400, width=800)
fig.update_layout(title_text='Avg Likes over the period (Positive Tweets)', title_x=0.5)
#fig.show()



fig = px.bar(df, x='data', y='avg_retweets',
             color='avg_retweets',
             labels={'data':'Dates',
                     'avg_retweets':'Avg Retweets'},
             height=400, width=800)
fig.update_layout(title_text='Avg Retweets over the period (Negative Retweets)', title_x=0.5)
#fig.show()
