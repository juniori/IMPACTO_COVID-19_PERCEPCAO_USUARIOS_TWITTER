# https://www.youtube.com/watch?v=TOb4BPg7Uh8&t=602s
# https://bhaskarvk.github.io/2015/01/how-to-use-twitters-search-rest-api-most-effectively./
# max_id e since_id  servem como limites superior e inferior

# Critérios de pesquisa que podem ser utilizados no twitter
#https://developer.twitter.com/en/docs/twitter-api/v1/tweets/search/guides/standard-operators


# pip install ConfigParser
'''
import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] - %(message)s',
    filename='main_twipy_search.log')
'''

import logging
logFormatter = logging.Formatter("%(asctime)s [%(threadName)-12.12s] [%(levelname)-5.5s]  %(message)s")
rootLogger = logging.getLogger()

fileHandler = logging.FileHandler("./main_twipy_search_log.log")
fileHandler.setFormatter(logFormatter)
rootLogger.addHandler(fileHandler)
rootLogger.setLevel(logging.INFO)

consoleHandler = logging.StreamHandler()
consoleHandler.setFormatter(logFormatter)
rootLogger.addHandler(consoleHandler)

import configparser
from datetime import datetime, timedelta
import pytz  # timezone
import os
import tweepy as tw
import nltk
# textblob

import pandas as pd
from tabulate import tabulate
import re
import spacy
import nltk
import sys
from googletrans import Translator
import nltk
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import numpy as np
from PIL import Image

# https://github.com/cjhutto/vaderSentiment#introduction


nltk.download('vader_lexicon')
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
import twipyUtil as util
import dbUtil as dbUtil
import tradutorUtil as tradutor
from tabulate import tabulate
# from nltk.sentiment.vader import SentimentIntensityAnalyzer
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

import time
import httpx

# import emoji

# print(util.polarity_scores("Only stupid people does not get vaccine"))
# print(util.polarity_scores("Only stupid people get vaccine"))
# print(util.polarity_scores("Only smart people does not get vaccine"))
# print(util.polarity_scores("Only smart people get vaccine"))
# print(util.polarity_scores("stupid"))
# sys.exit()


# Por padrão, a cada limit de 15 tweets a api faz um request. Esse limite pode ser aumentado alterando o parametro "count" : tw.Cursor(api.search, q="teste", count=tweetsPorQuery)
# Permite que eu veja a chamada http realizada pelo tweepy (a resposta desta chamada contém os valores atualizados das taxas limites)
#   header: x-rate-limit-limit: 450 // x-rate-limit-limit
#   header: x-rate-limit-remaining: 344 //the number of requests left for the 15 minute window
#   header: x-rate-limit-reset: 1590529305 //the remaining window before the rate limit resets
tw.debug(False)
logging.basicConfig(level=logging.INFO)

loadFromDatabase = False
tweet_details = []
randomString = "random" + util.randomString(15)

if loadFromDatabase:
    tweet_details = dbUtil.getFromDataBase()
else:

    # search_words = "(abertura OR reabertura) (comércio OR loja OR lojas OR shopping OR shoppings OR {})".format(randomString) #input("Termo:")#
    # search_words = "(abertura OR reabertura) (comércio OR loja OR shopping OR {})".format(randomString)  # input("Termo:")#
    # search_words = 'vacina AND (corona OR coronavírus OR "corona vírus" OR covid OR covid-19) OR 12454545478787879822222'
    # search_words = '(bolsonaro OR bolsominion OR bolsomito) AND (corona OR coronavírus OR "corona vírus" OR covid OR covid-19) AND (morreu OR faleceu OR falecimento)'
    # search_words = '"meu pai" OR "minha mãe" OR "meu filho" OR "minha filha" OR "meu tio" OR "minha tia" OR "meu avô" OR "minha avó" OR "meu irmão" OR "minha irmã" OR "meu primo" OR "minha prima" OR "meu sobrinho" OR "minha sobrinha" OR "meu cunhado" OR "minha cunhada" OR "meu sogro" OR "minha sogra") AND (morreu OR faleceu OR teve OR pegou OR internado OR curou OR curado OR melhorou OR "teve alta" OR "recebeu alta") AND (corona OR coronavírus OR "corona vírus" OR covid OR covid-19)'

    # Tweets covid
    #search_words = '"meu pai" OR "minha mãe" OR "meu filho" OR "minha filha" OR "meu tio" OR "minha tia" OR "meu avô" OR "minha avó" OR "meu irmão" OR "minha irmã" OR "meu primo" OR "minha prima" OR "meu sobrinho" OR "minha sobrinha" ) AND (morreu OR faleceu OR teve OR pegou OR internado OR curou OR curado OR melhorou OR "teve alta" OR "recebeu alta") AND (corona OR coronavírus OR "corona vírus" OR covid OR covid-19)'
    #table_name = 'dataset_tweets_bert'
    #flag = ''


    # Tweets treino
    #search_words ='#ForaBolsonaro'
    #table_name = 'dataset_tweets_bert_treino'
    #flag = 'C'

    # Tweets treino
    #search_words = '#FechadoComBolsonaro'
    #table_name = 'dataset_tweets_bert_treino'
    #flag = 'F'


    #Tweet voto impresso
    #search_words =  '#EuApoioVotoImpresso'
    #table_name = 'dataset_tweets_voto_impresso'
    #flag = ''

    # Pesquisa Disertação
    #search_words ='#19JForaBolsonaro'
    #table_name = 'dataset_tweets_eventos'
    #flag = ''


    termos = [
        {'search_words': '"meu pai" OR "minha mãe" OR "meu filho" OR "minha filha" OR "meu tio" OR "minha tia" OR "meu avô" OR "minha avó" OR "meu irmão" OR "minha irmã" OR "meu primo" OR "minha prima" OR "meu sobrinho" OR "minha sobrinha" ) AND (morreu OR faleceu OR teve OR pegou OR internado OR curou OR curado OR melhorou OR "teve alta" OR "recebeu alta") AND (corona OR coronavírus OR "corona vírus" OR covid OR covid-19)',
         'table_name': 'dataset_tweets_bert',
         'flag': ''
         }
           ]

    termos_eventos = [
        {
            'search_words':'#NasRuasVoltaLula OR #BolsonaroReeleito OR Briguem OR #2OutForaBolsonaro OR #FORABOLSONARO OR #2OutEuVou OR #2OutubroForaBolsonaro OR #2deOutubroForaBolsonaro OR #Dia2ForaBolsonaro OR #2Out OR #CiroNasRuas OR "FORA GENOCIDA" OR Lotado OR Fracasso OR "Agora o Bozo" -filter:retweets',
            'table_name': 'dataset_tweets_eventos',
            'flag': None,
            'isAtivo': False
         },
        {
            'search_words': '#2OutForaBolsonaro OR {} -filter:retweets',
            'table_name': 'dataset_tweets_eventos',
            'flag': None,
            'isAtivo': True
        },
        {
            'search_words': '#BolsonaroReeleito OR {} -filter:retweets',
            'table_name': 'dataset_tweets_eventos',
            'flag': None,
            'isAtivo': True
        },
        {
            'search_words': '#BolsonaroAte2026 OR {} -filter:retweets',
            'table_name': 'dataset_tweets_eventos',
            'flag': None,
            'isAtivo': True
        },
        {
            'search_words': '#ForaBolsonaro OR {} -filter:retweets',
            'table_name': 'dataset_tweets_eventos',
            'flag': None,
            'isAtivo': True
        }

    ]

    logging.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    logging.info("EXECUCAO INICIADA +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    logging.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    for termo in termos_eventos:
        if termo['isAtivo'] == False:
            continue;
        logging.info("Buscando termo:{}".format(termo))

        #min_id, max_id = dbUtil.getMinMaxId(termo['table_name'], termo['search_words'])
        min_id, max_id = None, None

        tweets = util.get_tweets_por_dia(
            search_words=termo['search_words'].format(randomString),
            dt_start="03/10/2021",
            dt_end="03/10/2021",
            since_id=None,
            max_id=None,
            total_tweets_dia=100000)
        #tweets = util.get_tweets(search_words=termo['search_words'],  total_tweets=20000)

        logging.info("Tweets recuperados: {}".format(len(tweets)))

        tweet_details = util.parse_tweet_to_array(tweets)
        logging.info("Parse realizado.")

        dbUtil.addToDatabase(tweet_details, termo['table_name'], termo['search_words'], termo['flag'], True)
        logging.info("Dados salvos!")

    logging.info("XXXXXXX Fim! XXXXXXXXX")

    # search_words = search_words + " -filter:retweets"
    #tweets = util.get_tweets_por_dia(search_words, "09/06/2021", '19/06/2021', 500)

    #tweets = util.get_tweets(search_words, 50000)
    #print("Tweets recuperados: {}".format(len(tweets)))

    # tweets = util.filtrar_tweets_invalidos(tweets)

    # tweets = tradutor.traduzir_pt_to_en(tweets)

    #tweet_details = util.parse_tweet_to_array(tweets)
    #dbUtil.addToDatabase(tweet_details, table_name, search_words, flag)

# -----------------------------------------------------



# for td in tweet_details:
# td['sentimento'] = util.polarity_scores(td['texto_en_limpo'], True)

'''
palavras_mais_frequentes = util.filtrarPalavrasPositivasENegativasEFrequencia(tweet_details)

print("PLOT NEU...............")
palavras_mais_frequentes_neu = util.obterFrequencia(palavras_mais_frequentes["NEU"],10)
palavras_mais_frequentes_neu = [i[0] for i in palavras_mais_frequentes_neu]
palavras_mais_frequentes_neu = tradutor.traduzir_texto_en_pt(palavras_mais_frequentes_neu) 
util.plotar_word_clod(" ".join(palavras_mais_frequentes_neu), 10)

print("PLOT POS...............")
palavras_mais_frequentes_pos = util.obterFrequencia(palavras_mais_frequentes["POS"],10)
palavras_mais_frequentes_pos = [i[0] for i in palavras_mais_frequentes_pos]
palavras_mais_frequentes_pos = tradutor.traduzir_texto_en_pt(palavras_mais_frequentes_pos)
util.plotar_word_clod(" ".join(palavras_mais_frequentes_pos), 10)

print("PLOT NEG...............")
palavras_mais_frequentes_neg = util.obterFrequencia(palavras_mais_frequentes["NEG"],10)
palavras_mais_frequentes_neg = [i[0] for i in palavras_mais_frequentes_neg]
palavras_mais_frequentes_neg = tradutor.traduzir_texto_en_pt(palavras_mais_frequentes_neg)
util.plotar_word_clod(" ".join(palavras_mais_frequentes_neg), 10)

'''

# --------------------------------------
# Sentimentos por dia
# --------------------------------------
# util.plotar_chart_sentimentos_por_dia(tweet_details)

# --------------------------------------
# Hashtagas pr dia
# --------------------------------------
# util.plotar_chart_hashtags_por_dia(tweet_details)

# --------------------------------------
# Exportação para o Eduardo
# --------------------------------------
# tweet_details = tweet_details[:500]
# tweet_df = pd.DataFrame(data=tweet_details, columns=['id', 'origem', 'destino', 'relacionamento', 'sentimento', 'texto', 'texto_limpo','texto_en_limpo', 'created_at', 'dt_insert_utc'])
# tweet_df_csv = tweet_df.filter(["id","texto_limpo","origem", "created_at"])
# tweet_df_csv.to_csv('./resources/coletas_twipy/tweet_df.csv', index=False, encoding='utf-8')


# -------------------------------------- 
# Exportar para html
# --------------------------------------
# pd.set_option('max_colwidth', 20)
# pd.set_option('display.max_columns', 4)chat

# tweet_df = tweet_df.filter(["id","origem","destino","relacionamento","sentimento",  "texto_limpo","created_at" ])
# tweet_df.rename(columns={'id': 'tweet Id', 'sentimento': 'sentimento','texto_limpo':'texto avaliado', 'created_at':'dt. publicação' }, inplace=True)
# print(tabulate(tweet_df, headers='keys', tablefmt='grid'))
# tweet_df.to_html('./resources/coletas_twipy/tweet_df.html', encoding='utf-8')

'''
vertices = set()
for v in tweet_details:
    vertices.add((v['origem'], v['origem']))
    vertices.add((v['destino'], v['destino']))

df_vertices = pd.DataFrame(data=vertices, columns=['id', 'label'])
df_vertices.to_csv("./resources/coletas_twipy/coletas_twipy_vertices.csv", index=False, encoding='utf-8')

arestas = set()
for v in tweet_details:
    arestas.add((v['origem'], v['destino'], v['relacionamento'], v['sentimento']))
    arestas.add((v['origem'], v['destino'], v['relacionamento'], v['sentimento']))

df_arestas = pd.DataFrame(data=arestas, columns=['Source', 'Target', 'Relacionamento', 'Sentimento'])
df_arestas.to_csv("./resources/coletas_twipy/coletas_twipy_arestas.csv", index=False, encoding='utf-8')
'''