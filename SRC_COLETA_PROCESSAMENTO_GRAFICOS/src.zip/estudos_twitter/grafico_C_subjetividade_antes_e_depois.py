import logging
logging.basicConfig(level=logging.INFO)
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np

def percToStr(perc):
    return str(perc).replace('.00','').replace('.',',') +'%'


base_path = "C:/Users/junior/Google Drive/_Mestrado/SEAN/Dissertacao_Celso/resources/datasets/exp2/"
records = base_path+"tweets_grafico_subjetividade_antes_e_depois.csv"


df = pd.read_csv(records)

perc_antes = df[df['flag'] == 'A']['perc'].sum().round(2)
perc_depois = df[df['flag'] == 'D']['perc'].sum().round(2)

df['flag'] = df['flag'].replace("A","Antes").replace("D","Depois");
df['cor'] = df['flag'].replace("Antes","#ef563b").replace("Depois","#636dfa")
df['flag'] = df['flag'].replace('Antes', 'Antes - ' + percToStr(perc_antes))
df['flag'] = df['flag'].replace('Depois', 'Depois - ' + percToStr(perc_depois))
df['sent_textblob_subjetividade_categ'] = df['sent_textblob_subjetividade_categ']+" - " + df['perc'].astype(str).apply(percToStr)


print(df.head(10))

fig = px.sunburst(df, path=['flag' ,'sent_textblob_subjetividade_categ'], values='count', color='cor',
                  color_discrete_map=dict(zip(df.cor, df.cor)), title = "Cálculo da subjetividade entre os grupos")
fig.update_layout(uniformtext=dict(minsize=25.5, mode='show'),  title_x=0.5)
fig.update_traces(textfont=dict(color="#000000"))
fig.show()