import logging
logging.basicConfig(level=logging.INFO)
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np


base_path = "C:/Users/junior/Google Drive/_Mestrado/SEAN/Dissertacao_Celso/resources/datasets/exp2/"
records = base_path+"tweets_grafico_subjetividade_tempo.csv"


df = pd.read_csv(records)

print(df.head(10))

#df_antes = df[df['flag']=='A']
#df_depois = df[df['flag']=='D']

df['flag'] = df['flag'].replace("A","Antes").replace("D","Depois");


fig = px.line(df, x="data", y= "textblob_avg_subjetividade",  height=400, width=800,
              labels={'data': 'Período', 'textblob_avg_subjetividade': 'Subjetividade', 'flag':'Grupo'}
              ,color='flag')
fig.update_traces(mode='markers+lines')
fig.update_layout(title_text='Subjetividade média no período', title_x=0.5)
fig.update_xaxes(range=[df['data'].min(), df['data'].max()])
#fig.update_xaxes(tickangle=45, tickformat="%m\n%Y")
fig.show()


################## SUBJETIVIDADE   ###########################

'''
fig = px.line(df_antes, x="data", y="avg_subjetividade",  height=400, width=600,
              labels={'data': 'Dates', 'avg_subjetividade': 'Subjectivity'})
fig.update_traces(mode='markers+lines')
fig.update_layout(title_text='Calculated mean of subjectivity over the period (Before)', title_x=0.5)
fig.update_xaxes(range=[df['data'].min(), df['data'].max()])
#fig.update_xaxes(tickangle=45)
fig.show()

fig = px.line(df_depois, x="data", y="avg_subjetividade",  height=400, width=600,
              labels={'data': 'Dates', 'avg_subjetividade': 'Subjectivity'})
fig.update_traces(mode='markers+lines')
fig.update_layout(title_text='Calculated mean of subjectivity over the period (After)', title_x=0.5)
fig.update_xaxes(range=[df['data'].min(), df['data'].max()])
fig.show()
'''