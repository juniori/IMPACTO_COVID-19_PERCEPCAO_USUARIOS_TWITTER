import spacy
import pandas as pd
import re
from spacy.tokens import Token
import nltk
import emoji
import time

#!python -m spacy download pt
spacy_nlp_pt = spacy.load('pt')
spacy_nlp_en = spacy.load('en')

NLTK_STOP_WORDS_EN = nltk.corpus.stopwords.words("english")
NLTK_STOP_WORDS_PT = nltk.corpus.stopwords.words("portuguese")


'''
ADJ: adjective, e.g. big, old, green, incomprehensible, first
ADP: adposition, e.g. in, to, during
ADV: adverb, e.g. very, tomorrow, down, where, there
AUX: auxiliary, e.g. is, has (done), will (do), should (do)
CONJ: conjunction, e.g. and, or, but
CCONJ: coordinating conjunction, e.g. and, or, but
DET: determiner, e.g. a, an, the
INTJ: interjection, e.g. psst, ouch, bravo, hello
NOUN: noun, e.g. girl, cat, tree, air, beauty
NUM: numeral, e.g. 1, 2017, one, seventy-seven, IV, MMXIV
PART: particle, e.g. ’s, not,
PRON: pronoun, e.g I, you, he, she, myself, themselves, somebody
PROPN: proper noun, e.g. Mary, John, London, NATO, HBO
PUNCT: punctuation, e.g. ., (, ), ?
SCONJ: subordinating conjunction, e.g. if, while, that
SYM: symbol, e.g. $, %, §, ©, +, −, ×, ÷, =, :), 😝
VERB: verb, e.g. run, runs, running, eat, ate, eating
X: other, e.g. sfpksdpsxmsa
SPACE: space, e.g.

'''

def remover_stopwords(text, idioma):
    #idioma = 'portuguese'
    #idioma = 'english'

    tokens = nltk.tokenize.word_tokenize(text.lower(), idioma)

    stopwords = NLTK_STOP_WORDS_PT if idioma == "portuguese" else NLTK_STOP_WORDS_EN

    filtered_sentence = [w for w in tokens if not w.lower() in stopwords]

    return ' '.join(filtered_sentence);


def lemma(texto, idioma, excluir=[], lematizar=[] ):
    idioma_pt = 'portuguese'
    idioma_en = 'english'

    texto = texto.lower();

    texto_nlp = ""
    if (idioma == idioma_pt):
        texto_nlp = spacy_nlp_pt(texto)
    elif (idioma == idioma_en):
         texto_nlp = spacy_nlp_en(texto);

    tokens_aceitos = []

    for token in texto_nlp:
        #print('(',token.text, token.pos_,')')
        if excluir == [] or not token.pos_ in excluir: # ['SYM', 'NUM', 'PRON', 'PUNCT', 'SPACE', 'DET', 'CCONJ' ]
            if lematizar == ['ALL'] or token.pos_ in lematizar: # ['NOUN', 'ADJ','VERB']::
                tokens_aceitos.append(token.lemma_)
            else:
                tokens_aceitos.append(token.text)


    resultado = ' '.join(tokens_aceitos);

    return re.sub(r' +', ' ', resultado).lower();

def removeEmoji(texto, language):
    english = 'en'
    portuguese = 'pt'

    if language == 'portuguese':
        language = 'pt'
    elif language == 'english':
        language = 'en'

    texto = ''.join(c for c in texto if c not in emoji.UNICODE_EMOJI[language])
    emoji_pattern = re.compile("["
                      u"\U0001F600-\U0001F64F"  # emoticons
                      u"\U0001F300-\U0001F5FF"  # symbols & pictographs
                      u"\U0001F680-\U0001F6FF"  # transport & map symbols
                      u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                      u"\U00002500-\U00002BEF"  # chinese char
                      u"\U00002702-\U000027B0"
                      u"\U00002702-\U000027B0"
                      u"\U000024C2-\U0001F251"
                      u"\U0001f926-\U0001f937"
                      u"\U00010000-\U0010ffff"
                      u"\u2640-\u2642"
                      u"\u2600-\u2B55"
                      u"\u200d"
                      u"\u23cf"
                      u"\u23e9"
                      u"\u231a"
                      u"\ufe0f"  # dingbats
                      u"\u3030"
                               "]+", re.UNICODE)
    texto = emoji_pattern.sub(r'', texto)
    return texto



#print(lemma("perder",'portuguese'))

# english



