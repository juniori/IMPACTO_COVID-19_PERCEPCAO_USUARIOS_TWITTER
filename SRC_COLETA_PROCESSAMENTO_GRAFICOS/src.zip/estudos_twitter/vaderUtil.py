#https://textblob.readthedocs.io/en/dev/quickstart.html#sentiment-analysis

from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import twipyUtil as twipyUtil
import time
import nltk
import textoUtil

import spacy

#!python -m spacy download pt
spacy_nlp_pt = spacy.load('pt')
spacy_nlp_en = spacy.load('en')


SID = SentimentIntensityAnalyzer()

def vader_polarity_scores_categ_and_subcateg(text_en,   print_words = False):

    #new_words = {'genocide': -3.9} # mesma pontuação de assassino (Killer-3.3) ou  estupador (rapist -3.9)
    #new_words = {'chipped': -2} # mesma pontuação de assassino (Killer-3.3) ou  estupador (rapist -3.9)
    #SID.lexicon.update(new_words)

    polaridade = SID.polarity_scores(text_en)
    compound = polaridade['compound']

    return twipyUtil.polarity_to_categ_and_subcateg(compound)


def palavras_not_in_lexicon_vader(text_en):
  #tokens = nltk.tokenize.word_tokenize(text_en)

  tokens = spacy_nlp_en(text_en);

  for t in tokens:
      print(t.text.lower())
  lexicons = SentimentIntensityAnalyzer().lexicon
  in_lexicons = [w.text for w in tokens if w.text.lower() in lexicons]
  not_in_lexicons = [w.text for w in tokens if not w.text.lower() in lexicons]
  return in_lexicons, not_in_lexicons

'''
sentenca_original = "Are the people offended why did they put Bolsonaro in a wig to represent Sarah’s mother?If you like him why are they angry?I was going to be very happy if they put the wig squid to represent my mother. She even laughing ..."
sentenca = textoUtil.remover_stopwords(sentenca_original, "english")
print(sentenca)
for w in sentenca.split(" "):
    #print(w,vader_polarity_scores_categ_and_subcateg(w));
    print('')

print(sentenca_original,vader_polarity_scores_categ_and_subcateg(sentenca_original));
print(sentenca,vader_polarity_scores_categ_and_subcateg(sentenca));
'''


#print(sentenca_original,vader_polarity_scores_categ_and_subcateg(sentenca_original));