import logging
logging.basicConfig(level=logging.INFO)
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go


ferramentas = ["vader", "textblob", "polyglot","polyglot_pt"]
graficos = ["Antes", "Depois", "Antes e Depois"]
#ferramentas = ["vader"]

base_path = "C:/Users/junior/Google Drive/_Mestrado/SEAN/Dissertacao_Celso/resources/datasets/exp2/"
records = base_path + "tweets_grafico_dispersao.csv"

df = pd.read_csv(records)

print(df.shape)
print(df.head(10))


for ferramenta in ferramentas:


    for grafico in graficos:
        fig = go.Figure()
        # Add traces

        if grafico in ("Antes", "Antes e Depois"):
            fig.add_trace(go.Scatter(x=df[ferramenta+'_avg_polaridade_antes'], y=df['qtd_antes'],  mode='markers', name='Usuários Antes'))
        if grafico in ("Depois", "Antes e Depois"):
            fig.add_trace(go.Scatter(x=df[ferramenta+'_avg_polaridade_depois'], y=df['qtd_depois'], mode='markers',name='Usuários Depois',  marker=dict(color='Red')))


        fig.update_layout(
            title='Compound x Amount Tweets ('+grafico+') '+ferramenta,
            title_x=0.5,
            xaxis_title="Polaridade Média",
            yaxis_title="Quantidade de Tweets",
            width=900,
            height=500,
            legend=dict(
                x=0.75,
                y=0.98,
                traceorder="normal"),
            xaxis=dict(
                tickmode='array',
                tickvals=[-0.1, -0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8, 1],
                ticktext=[-0.1, -0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8, 1],
            )

        )


        fig.update_xaxes(range=[-1, 1])

        fig.update_xaxes(
            # tickangle=45
        )

        fig.show()

