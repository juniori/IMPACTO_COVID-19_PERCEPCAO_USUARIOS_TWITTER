import logging
logging.basicConfig(level=logging.INFO)


import twipyUtil as util
import dbUtil as dbUtil
import tweepy as tw
import time
import pandas as pd
import sys as sys
from datetime import datetime
import tradutorUtil as tradutor
import sys
import twipyUtil as twipyUtil
from textblob import TextBlob
tw.debug(False)


records = dbUtil.getFromDataBase("dataset_tweets_base_2021_hiccs_manual", where="where relacionamento is null")
print(len(records))
for i, r in enumerate(records):
    if i>0 and (i%100 ==0):
        print("processados:",i)
    texto_limpo = twipyUtil.limpar_texto(r['texto'])
    dbUtil.update_texto_limpo("dataset_tweets_base_2021_hiccs_manual", r['id'], texto_limpo)



'''
texto = "@parasamuel @ConexaoPetista @JosDonizettiVi3 @sequeira_kg @prudentemarlene @Alexand92840726 @anandacajueiro @CeliaAdevogada @cassiaeli9 @ana_mota57 @fdesouzaalves @JorgeLuizNogu11 @AliceDdos @LulinhaMeu @DanilosLeite @MariaDoPT_13 @VanisedaSilvaC1 @BarrettoAlmeida @josehenriquefb @leiaflaviano @SoniaCaiuba Isso mesmo companheiro Samuel!Não existe vitórias sem lutas!Somos resistência, a vitória vai chegar!🚩👊🚩❤️#Dia29ForaBolsonaro"
texto_limpo = twipyUtil.limpar_texto(texto)
print("texto:"+ texto)
print("texto_limpo:"+ texto_limpo)
'''

