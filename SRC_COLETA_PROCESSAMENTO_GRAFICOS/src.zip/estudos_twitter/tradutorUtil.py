import logging
logging.basicConfig(level=logging.INFO)
import re
from googletrans import Translator
from googletrans.constants import (
    DEFAULT_SERVICE_URLS
)
import requests
from bs4 import BeautifulSoup
from itertools import cycle
import twipyUtil as util
import dbUtil as dbUtil
import random
import time
import sys




def get_proxies():
    # https://www.python-httpx.org/advanced/#http-proxying
    # https://free-proxy-list.net/
    # https://api.myip.com/
    PROXY_URL = 'https://free-proxy-list.net/'

    response = requests.get(PROXY_URL)
    soup = BeautifulSoup(response.text, 'lxml')
    table = soup.find('table', id='proxylisttable')
    list_tr = table.find_all('tr')
    list_td = [elem.find_all('td') for elem in list_tr]
    list_td = list(filter(None, list_td))
    list_ip = [elem[0].text for elem in list_td]
    list_ports = [elem[1].text for elem in list_td]
    list_proxies = [':'.join(elem) for elem in list(zip(list_ip, list_ports))]
    return list_proxies


proxies = [] #get_proxies() // Ajustar o código acima,pois o html da página "https://free-proxy-list.net/" mudou

proxies = ['131.72.69.150:40033']

proxy_pool = cycle(proxies)


def get_tradutor_instance():
    service_urls = ['translate.google.ws', 'translate.google.com', 'translate.google.co.kr']

    HEADERS_LIST = [
        'Mozilla/5.0 (Windows; U; Windows NT 6.1; x64; fr; rv:1.9.2.13) Gecko/20101203 Firebird/3.6.13',
        'Mozilla/5.0 (compatible, MSIE 11, Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko',
        'Mozilla/5.0 (Windows; U; Windows NT 6.1; rv:2.2) Gecko/20110201',
        'Opera/9.80 (X11; Linux i686; Ubuntu/14.10) Presto/2.12.388 Version/12.16',
        'Mozilla/5.0 (Windows NT 5.2; RW; rv:7.0a1) Gecko/20091211 SeaMonkey/9.23a1pre'
    ]

    HEADER = random.choice(HEADERS_LIST)

    logging.info(HEADER)
    proxy = {"http": "http://" + next(proxy_pool)}
    logging.info(proxy)

    #translator = Translator(service_urls=service_urls, user_agent=HEADER, proxies=proxy, raise_exception=True)

    translator = Translator(service_urls=service_urls, user_agent=HEADER, proxies=proxy, raise_exception=True)
    translator.raise_Exception = True

    #translator = Translator()

    return translator

def traduzir_pt_to_en(tweets_):
    logging.info('traduzir_pt_to_en:{}'.format(str(len(tweets_))))

    lista = [[]]

    max_size = 10000  # Máximo da Api são 15.000 caracteres
    size = 0

    tweets_existentes = []
    tweets_novos = []
    for t in tweets_:
        reg = None
        try:
            reg = dbUtil.getById('dataset_tweets_bert_timeline', t['id'])
        except Exception as e:
            reg = dbUtil.getById('dataset_tweets_bert_timeline', t.id)

        if not (reg is None or len(reg['texto_en_limpo']) == 0):
            try:
                t['full_text_en'] = reg['texto_en_limpo']
            except Exception as e:
                setattr(t, 'full_text_en', reg['texto_en_limpo'])

            tweets_existentes.append(t)
        else:
            tweets_novos.append(t)

    logging.info('Tweets existentes:{}'.format(str(len(tweets_existentes))))
    logging.info('Tweets novos (A traduzir):{}'.format(str(len(tweets_novos))))
    time.sleep(2)

    for t in tweets_novos:

        index = len(lista) - 1
        try:
            lista[index].append(util.limpar_texto(util.remover_break_lines(t['texto_limpo'])))
            size = size + len(t['texto_limpo'])
        except Exception as e:
            lista[index].append(util.limpar_texto(util.remover_break_lines(t.full_text)))
            size = size + len(t.full_text)

        if (size >= max_size):
            lista.append([lista[index].pop()])
            size = 0

    itens_fila_processados = 0


    logging.info('Itens na fila para tradução:{}'.format(str(len(lista))))
    for i in range(len(lista)):
        translator = get_tradutor_instance()
        itens_fila_processados = itens_fila_processados + 1
        logging.info('** Processando:{} de {} '.format(itens_fila_processados, str(len(lista))))

        '''
    str_temp = ' MWM '.join(lista[i])
    str_temp = util.limpar_texto(str_temp)
    str_temp = str_temp.replace("...","")
    logging.info('Item ' + str(i) + ' traduzir. Tam: '+ str(len(lista[i])-1)+' - ' + str_temp)
    str_temp = util.remover_break_lines(str_temp)
    str_temp = translator.translate(str_temp, src="pt", dest="en").text
    #lista[i] = str_temp.split('<code></code>')
    lista[i] = re.split(r'MWM',str_temp)

    logging.info('Item ' + str(i) + ' traduzido. Tam: ' + str(len(lista[i])) + ' - ' + str_temp)
    #time.sleep(2)
    '''

        logging.info('Tweets a traduzir. Tam:{} : {}'.format(len(lista[i]), lista[i]))
        itens = translator.translate(lista[i], src="pt", dest="en")
        lista[i] = [item.text for item in itens]
        logging.info('Tweets traduzidos. Tam:{} : {}'.format(len(lista[i]), lista[i]))

        time.sleep(2)

    lista = [y for x in lista for y in x]

    logging.info('Qtd tweets: ' + str(len(tweets_novos)))
    logging.info('Qtd itens traduzidos: ' + str(len(lista)))
    novaLista = []
    for i in range(len(tweets_novos)):
        # tweets[i].full_text = lista[i]
        try:
            tweets_novos[i]['full_text_en'] = lista[i]
        except Exception as e:
            setattr(tweets_novos[i], "full_text_en", lista[i])

        novaLista.append(tweets_novos[i])

    logging.info('Tweets existentes:{}'.format(str(len(tweets_existentes))))
    logging.info('Tweets novos (Traduzidos):{}'.format(str(len(novaLista))))

    return novaLista + tweets_existentes


def traduzir_tweet_pt_to_en(tweets_array):

    logging.info('traduzir_tweet_pt_to_en:{}'.format(str(len(tweets_array))))

    lista = [[]]

    max_size = 10000  # Máxido da Api é 15.000 caracteres
    size = 0

    tweets_novos = []

    for t in tweets_array:

        reg = None
        reg = dbUtil.getById('dataset_tweets_bert_timeline_1', t['id'])

        if len(reg['texto_en_limpo']) == 0:
            tweets_novos.append(t);

    logging.info('Tweets novos (A traduzir):{}'.format(str(len(tweets_novos))))
    time.sleep(2)


    for t in tweets_novos:

        index = len(lista) - 1
        lista[index].append(util.remover_break_lines(t['texto_limpo']))
        size = size + len(t['texto_limpo'])

        if (size >= max_size):
            lista.append([lista[index].pop()])
            size = 0

    itens_fila_processados = 0

    logging.info('Itens na fila para tradução:{}'.format(str(len(lista))))

    translator = get_tradutor_instance();

    for i in range(len(lista)):


        itens_fila_processados = itens_fila_processados + 1;

        logging.info('** Processando:{} de {} '.format(itens_fila_processados, str(len(lista))));

        logging.info('Tweets a traduzir. Tam:{} : {}'.format(len(lista[i]), lista[i]));
        itens = translator.translate(lista[i],  dest="en");
        lista[i] = [item.text for item in itens];
        logging.info('Tweets traduzidos. Tam:{} : {}'.format(len(lista[i]), lista[i]));

        time.sleep(2)

    lista = [y for x in lista for y in x]

    logging.info('Qtd tweets: ' + str(len(tweets_novos)));
    logging.info('Qtd itens traduzidos: ' + str(len(lista)));
    novaLista = [];
    for i in range(len(tweets_novos)):
        tweets_novos[i]['texto_en_limpo'] = lista[i]
        novaLista.append(tweets_novos[i])

    logging.info('Tweets novos (Traduzidos):{}'.format(str(len(novaLista))))

    return novaLista



def traduzir_tweet_pt_to_en2(tweets_array):

    logging.info('traduzir_tweet_pt_to_en2:{}'.format(str(len(tweets_array))))

    lista = [[]]

    max_size = 10000  # Máxido da Api é 15.000 caracteres
    size = 0

    tweets_novos = []

    for t in tweets_array:
        reg = None
        reg = dbUtil.getById('dataset_tweets_bert_timeline_1', t['id'])
        # Verifica se ainda não foi traduzido
        if len(reg['texto_en_limpo']) == 0:
            tweets_novos.append(t);

    logging.info('Tweets novos (A traduzir):{}'.format(str(len(tweets_novos))))
    time.sleep(2)


    for t in tweets_novos:

        index = len(lista) - 1
        lista[index].append(util.remover_break_lines(t['texto_limpo']))
        size = size + len(t['texto_limpo'])

        if (size >= max_size):
            lista.append([lista[index].pop()])
            size = 0

    itens_fila_processados = 0

    logging.info('Itens na fila para tradução:{}'.format(str(len(lista))))

    translator = get_tradutor_instance();

    for i in range(len(lista)):


        itens_fila_processados = itens_fila_processados + 1;

        logging.info('** Processando:{} de {} '.format(itens_fila_processados, str(len(lista))));

        logging.info('Tweets a traduzir. Tam:{} : {}'.format(len(lista[i]), lista[i]));
        #itens = translator.translate(lista[i],  dest="en");
        itens = traduzir_lista(lista[i])
        #lista[i] = [item.text for item in itens];
        lista[i] = itens;
        #logging.info('Tweets traduzidos. Tam:{} : {}'.format(len(lista[i]), lista[i]));
        logging.info('Qtd Tweets traduzidos:{}'.format(len(lista[i])));

        time.sleep(2)

    lista = [y for x in lista for y in x]

    logging.info('Qtd tweets: ' + str(len(tweets_novos)));
    logging.info('Qtd itens traduzidos: ' + str(len(lista)));
    novaLista = [];
    for i in range(len(tweets_novos)):
        tweets_novos[i]['texto_en_limpo'] = lista[i]
        novaLista.append(tweets_novos[i])

    logging.info('Tweets novos (Traduzidos):{}'.format(str(len(novaLista))))

    return novaLista

def traduzir_tweet_pt_to_en3(tweets_array):

    logging.info('traduzir_tweet_pt_to_en3:{}'.format(str(len(tweets_array))))

    # Um array somente com o texto a ser traduzido
    lista = [t['texto_limpo'] for t in tweets_array]

    lista_traduzida = traduzir_lista(lista)

    if len(lista) != len(lista_traduzida):
        raise Exception("A qtd dos itens a serem traduzidos[{}] difere da qtd de itens que foi traduzidos[{}].".format(len(lista), len(lista_traduzida)))

    for i in range(len(tweets_array)):
        tweets_array[i]['texto_en_limpo'] = lista_traduzida[i]

    return tweets_array;

def traduzir_texto_en_pt(list_of_words):
    translator = get_tradutor_instance()
    itens = translator.translate(list_of_words, src="en", dest="pt")
    lista = [item.text for item in itens]
    return lista

#def tratuzir_lista(src, dest, strList):
#    translator = get_tradutor_instance()
#    translations = translator.translate(strList)
#    for translation in translations:
#        print(translation.origin, ' -> ', translation.text)


def traduzir_lista(strList):
    lista= []
    for frase in strList:
        try:
            translator = get_tradutor_instance()
            translations = translator.translate(frase, src="pt", dest="en")
            texto_en = translations.text
            logging.info("texto_pt: {}".format(frase))
            logging.info("texto_en: {}".format(texto_en))
            lista.append(texto_en)
        except Exception as e:
            print("Erro ao traduzir:{}".format(e))
            lista.append('')
    return lista


#trads = traduzir_lista(['GENOCIDA! Pazuello confirmou à CPI que Bolsonaro estava na reunião ministerial que decidiu não intervir na crise de oxigên…'])
#trads = traduzir_lista(['Bolsonaro para presidente do Twitter'])
#for t in trads:
#    print(t)
