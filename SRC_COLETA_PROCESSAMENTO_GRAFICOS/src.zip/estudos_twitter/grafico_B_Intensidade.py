import logging
logging.basicConfig(level=logging.INFO)
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
import numpy as np
#Ref: https://plotly.com/python/sunburst-charts/

def percToStr(perc):
    return str(perc).replace('.0','').replace('.',',') +'%' 

ferramentas = ["VADER", "TEXTBLOB", "POLYGLOT","POLYGLOT_PT"]
ferramentas = ["VADER"]
graus_acomentimento = ["1", "2", "3"]
graus_acomentimento = ["3"]
familiares = ["avô_avó", "pai_mãe", "filho_filha", "irmão_irmã"]
familiares=["avô_avó"]

for ferramenta in ferramentas:

    for grau in graus_acomentimento:

        for familiar in familiares:

            base_path = "C:/Users/junior/Google Drive/_Mestrado/SEAN/Dissertacao_Celso/resources/datasets/exp2/"

            #records_antes = base_path + ferramenta + "_tweets_grafico_intensidade_antes.csv"
            #records_depois = base_path + ferramenta + "_tweets_grafico_intensidade_depois.csv"

            #records_antes = base_path + ferramenta + "_tweets_grafico_intensidade_antes_iforte.csv"
            #records_depois = base_path + ferramenta + "_tweets_grafico_intensidade_depois_iforte.csv"

            #records_antes = base_path + ferramenta + "_tweets_grafico_intensidade_antes_grauacometimento"+grau+ ".csv"
            #records_depois = base_path + ferramenta + "_tweets_grafico_intensidade_depois_grauacometimento"+grau+ ".csv"

            records_antes = base_path + ferramenta + "_tweets_grafico_intensidade_antes_"+familiar+ ".csv"
            records_depois = base_path + ferramenta + "_tweets_grafico_intensidade_depois_"+familiar+ ".csv"



            df_antes = pd.read_csv(records_antes)
            df_depois = pd.read_csv(records_depois)
            df_antes.fillna('Neutro  ', inplace=True)
            df_depois.fillna('Neutro  ', inplace=True)

            print(df_antes.head(50))
            print("df_antes['perc'].sum()", df_antes['perc'].sum())
            print("df_antes['qtd'].sum()", df_antes['qtd'].sum())
            print("-------------------------------------")
            print(df_depois.head(50))
            print("df_depois['perc'].sum()", df_depois['perc'].sum())
            print("df_depois['qtd'].sum()", df_depois['qtd'].sum())


            perc_neg =  df_antes[df_antes['categ'] == 'NEG']['perc'].sum().round(2)
            perc_neu =  df_antes[df_antes['categ'] == 'NEU']['perc'].sum().round(2)
            perc_pos =  df_antes[df_antes['categ'] == 'POS']['perc'].sum().round(2)

            df_antes[['categ', 'subcateg']] = df_antes['subcateg'].str.split(' ', 1, expand=True)
            df_antes['cor'] = df_antes['categ'].replace("Negativo","#ef563b").replace("Positivo","#636dfa").replace("Neutro","#00cc96")
            df_antes['categ'] = df_antes['categ'].replace('Negativo', 'Negativo - ' + percToStr(perc_neg))
            df_antes['categ'] = df_antes['categ'].replace('Neutro', 'Neutro - ' + percToStr(perc_neu))
            df_antes['categ'] = df_antes['categ'].replace('Positivo', 'Positivo - ' + percToStr(perc_pos))
            df_antes['subcateg'] = df_antes['subcateg'].map(str) + " - " + df_antes['perc'].map(str) + "%"
            df_antes['subcateg'] = df_antes['subcateg'].str.replace(".0", "", regex=False)
            df_antes['subcateg'] = df_antes['subcateg'].str.replace(".", ",", regex=False)
            df_antes.replace(r'^\s', np.nan, regex=True, inplace=True)
            df_antes['flag'] = df_antes['flag'].replace('A', 'Antes<br>' + ferramenta)
            print(df_antes.head(50))


            fig1 = px.sunburst(df_antes, path=['categ', 'subcateg'], values='qtd', color='cor',
                               color_discrete_map=dict(zip(df_antes.cor, df_antes.cor)))
            fig1.update_layout(uniformtext=dict(minsize=20.5, mode='show'),
                               title_text='Polaridade entre os tweets antes -' + familiar + '- ('+ferramenta+ ')',
                               title_x=0.5)
            fig1.update_traces(textfont=dict(color="#000000"),  sort=False)
            fig1.show()

            ################################## DEPOIS ######################################

            perc_neg =  df_depois[df_depois['categ'] == 'NEG']['perc'].sum().round(2)
            perc_neu =  df_depois[df_depois['categ'] == 'NEU']['perc'].sum().round(2)
            perc_pos =  df_depois[df_depois['categ'] == 'POS']['perc'].sum().round(2)

            df_depois[['categ', 'subcateg']] = df_depois['subcateg'].str.split(' ', 1, expand=True)
            df_depois['cor'] = df_depois['categ'].replace("Negativo","#ef563b").replace("Positivo","#636dfa").replace("Neutro","#00cc96")
            df_depois['categ'] = df_depois['categ'].replace('Negativo', 'Negativo - ' + percToStr(perc_neg))
            df_depois['categ'] = df_depois['categ'].replace('Neutro', 'Neutro - ' + percToStr(perc_neu))
            df_depois['categ'] = df_depois['categ'].replace('Positivo', 'Positivo - ' + percToStr(perc_pos))
            df_depois['subcateg'] = df_depois['subcateg'].map(str) + " - " + df_depois['perc'].map(str) + "%"
            df_depois['subcateg'] = df_depois['subcateg'].str.replace(".0", "", regex=False)
            df_depois['subcateg'] = df_depois['subcateg'].str.replace(".", ",", regex=False)
            df_depois.replace(r'^\s', np.nan, regex=True, inplace=True)
            df_depois['flag'] = df_depois['flag'].replace('D', 'Depois<br>' + ferramenta)
            print(df_depois.head(50))

            fig2 = px.sunburst(df_depois, path=['categ', 'subcateg'], values='qtd', color='cor',
                               color_discrete_map=dict(zip(df_depois.cor, df_depois.cor)))
            fig2.update_layout(uniformtext=dict(minsize=20.5, mode='show'),
                               title_text='Polaridade entre os tweets  depois -' + familiar + '- ('+ferramenta+ ')',
                               title_x=0.5)
            fig2.update_traces(textfont=dict(color="#000000"), sort =False)
            fig2.show()

