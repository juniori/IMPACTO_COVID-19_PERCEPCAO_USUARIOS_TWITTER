import logging
logging.basicConfig(level=logging.INFO)
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np
pd.set_option('display.max_columns', None)

#Ref: https://plotly.com/python/radar-chart/

def normalizeData(data):
    return (data - np.min(data)) / (np.max(data) - np.min(data))

idiomas = ["en","pt"]
grupos = ["A","D"]
ferramentas = ["vader", "textblob", "polyglot", "polyglot_pt"]
polaridades = ["NEG", "POS", "NEU"]
#polaridades = []


base_path = "C:/Users/junior/Google Drive/_Mestrado/SEAN/Dissertacao_Celso/resources/datasets/exp2/"
records = base_path + "syuzhet_sentimentos_pt_and_en.csv"

df_inicial = pd.read_csv(records)

#df_inicial = df_inicial[df_inicial.relacionamento == "tweet"]
#df_inicial = df_inicial[df_inicial.sent_textblob_subjetividade_categ == "Forte"]

old = ["anger","anticipation","disgust","fear","joy","sadness","surprise","trust"]
new = ["Raiva", "Expectativa", "Nojo", "Medo", "Alegria", "Tristeza", "Surpresa",  "Confiança"]
columns = zip(new, old)
column_names = dict((x, y) for y, x in columns)

print(column_names)

df_inicial.rename(columns = column_names, inplace = True)


def plotar_grafico(df, idioma, grupo, polaridade, isMultiline = False ):

    df = df[["flag", "Raiva", "Expectativa", "Nojo", "Medo", "Alegria", "Tristeza", "Surpresa", "Confiança"]]
    print("Idioma:{}, grupo:{}, polaridade:{}".format(idioma, grupo, polaridade))
    # print(df.dtypes)
    # print(df.head(10))
    # print(df[df.flag == "A"].describe())
    # print(df[df.flag == "D"].describe())
    df = df.groupby('flag').mean()
    print(df.head(10))
    column_headers = ["Raiva", "Expectativa", "Nojo", "Medo", "Alegria", "Tristeza", "Surpresa", "Confiança"]

    if not isMultiline:

        fig = px.line_polar(r=df[column_headers].loc[grupo].values, theta=column_headers, line_close=True)
        fig.update_traces(fill='toself')
        fig.update_layout(title_text='Emoções - (idioma:{} polaridade:{} grupo:{})'.format(idioma, polaridade, grupo),
                          title_x=0.5, font=dict(size=25), title_font_size=10)
        fig.show()
    else:

        fig = go.Figure()

        fig.add_trace(go.Scatterpolar(
            r=df[column_headers].loc['A'].values,
            theta=column_headers,
            fill='toself',
            name='Antes'
        ))
        fig.add_trace(go.Scatterpolar(
            r=df[column_headers].loc['D'].values,
            theta=column_headers,
            fill='toself',
            name='Depois',
            line_dash = 'longdash'  # ['solid', 'dot', 'dash', 'longdash', 'dashdot', 'longdashdot']

        ))

        fig.update_layout(
            polar=dict(
                radialaxis=dict(
                    visible=True
                )),
            showlegend=True
        )

        fig.show()




for idioma in idiomas:

    df_idioma = df_inicial[df_inicial.idioma == idioma]

    plotar_grafico(df_idioma, idioma, "Todos", "Todas", isMultiline=True)

    for grupo in grupos:
        df_grupo = df_idioma[df_idioma.flag == grupo]

        plotar_grafico(df_grupo, idioma, grupo, "Todas")

        for polaridade in polaridades:
            df_polaridade = None
            if idioma == "en":
                df_polaridade = df_grupo[df_grupo.sent_vader_categ == polaridade]
            else:
                df_polaridade = df_grupo[df_grupo.sent_poli_categ_pt == polaridade]
            plotar_grafico(df_polaridade, idioma, grupo, polaridade)



