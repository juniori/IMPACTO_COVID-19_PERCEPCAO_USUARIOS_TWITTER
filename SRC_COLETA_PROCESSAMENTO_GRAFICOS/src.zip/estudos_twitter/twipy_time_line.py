# ##########################################################
# Tweets - User Timeline API
# Recuperar tweets e retweets de um usuário
# Referências:
# https://docs.tweepy.org/en/latest/api.html#tweepy.API.user_timeline
# https://developer.twitter.com/en/docs/twitter-api/v1/tweets/timelines/api-reference/get-statuses-user_timeline
# ##########################################################
import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] - %(message)s',
    filename='twipy_time_line.log')


import twipyUtil as util
import dbUtil as dbUtil
import tweepy as tw
import time
import pandas as pd
import sys as sys
tw.debug(False)

def getFromUserTimeLine(api, user_screen_name, since_id, max_id):
    tweets = []

    try:
        for page in tw.Cursor(api.user_timeline
                , screen_name=user_screen_name
                , count=200  # Qtd de tweets retornados por página (default:20, maximo: 200)
                , skip_status=True
                , exclude_replies=True
                , include_rts=True
                , tweet_mode="extended"
                , since_id= since_id
                , max_id = max_id
                              ).pages():
            tweets.extend(page)
            time.sleep(0.5)
    except Exception as e:
        logging.info("Erro!! {} **************************************************************".format(str(e)))


    return tweets


base_path = "C:/Users/junior/Documents/jupterNotebooks/BERT/resources/datasets/"
dataset_usuarios_unicos_path = base_path+"usuarios_unicos2.csv"

df = pd.read_csv(dataset_usuarios_unicos_path)

user_screen_names = df[["origem", "primeiro_tweet_id", "ultimo_tweet_id", "primeiro_tweet_data","ultimo_tweet_data"]]
user_screen_names.sort_values(by=['origem'], inplace=True, ascending=True)


iniciado = False
iniciar_em = "___eumari"

api = util.get_tweepy_api_conected()

for index, row in user_screen_names.iterrows():

    if (iniciado == False and row['origem'] != iniciar_em):
        continue
    else:
        iniciado = True

    try:
        since_id_antes = None
        max_id_antes   = row['primeiro_tweet_id']
        since_id_depois = row['ultimo_tweet_id']
        max_id_depois   = None
        logging.info("-----------------------------------------------------------------------------------------")
        logging.info("Processando DataFrameIndex:[{}], autor:[{}]".format(index, row['origem']))

        logging.info("primeiro_tweet_id:[{}], primeiro_tweet_data:[{}]".format(row['primeiro_tweet_id'],row['primeiro_tweet_data']))
        logging.info("ultimo_tweet_id:[{}], ultimo_tweet_data:[{}]".format(row['ultimo_tweet_id'],row['ultimo_tweet_data']))

        logging.info("since_id_antes[{}], max_id_antes[{}]".format(since_id_antes, max_id_antes ))
        logging.info("since_id_depois[{}], max_id_depois[{}]".format(since_id_depois, max_id_depois))
        logging.info("-----------------------------------------------------------------------------------------")

        # Coletando tweets antes do fato
        tweets_antes = getFromUserTimeLine(api, row['origem'], since_id_antes, max_id_antes-1) # max_id_antes-1 para não trazer o twitter do fato inclusive
        logging.info("tweets_antes: {}".format(len(tweets_antes)))
        tweet_details_antes = util.parse_tweet_to_array(tweets_antes)

        dbUtil.addToDatabase(tweet_details_antes, 'dataset_tweets_bert_timeline', row['origem'], 'A')

        #Coletando tweets depois do fato
        tweets_depois = getFromUserTimeLine(api, row['origem'], since_id_depois + 1, max_id_depois)
        logging.info("tweets_depois: {}".format(len(tweets_depois)))
        tweet_details_depois = util.parse_tweet_to_array(tweets_depois)
        dbUtil.addToDatabase(tweet_details_depois, 'dataset_tweets_bert_timeline', row['origem'], 'D')
    except Exception as e:
        logging.info("Erro!! {} **************************************************************".format(str(e)))


