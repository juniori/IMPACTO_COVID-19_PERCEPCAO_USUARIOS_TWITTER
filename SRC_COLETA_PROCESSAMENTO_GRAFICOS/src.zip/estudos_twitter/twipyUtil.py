import re
#import nltkvaderSentiment
import nltk
from googletrans import Translator
import time
# http://www.nltk.org/nltk_data/
#from nltk.sentiment.vader import SentimentIntensityAnalyzer

from wordcloud import WordCloud
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import numpy as np
from PIL import Image
import os
import logging
import tweepy as tw
import configparser
from datetime import datetime, timedelta
import collections
import pandas as pd
from tabulate import tabulate
import pytz  # timezone
import json
import random
import string
import textoUtil as textoUtil

logging.basicConfig(level=logging.INFO)


def get_tweepy_api_conected(id=""):
    config = configparser.ConfigParser()
    #config.read('./resources/twitter_Celso.properties')
    #config.read('./resources/twitter' + id + '.properties')
    config.read(os.path.dirname(os.path.abspath(__file__)) + '\\resources\\twitter' + id + '.properties')
    # print(config.sections())

    consumerkey = config.get('twitter', 'consumerkey')
    consumersecret = config.get('twitter', 'consumersecret')
    accesstoken = config.get('twitter', 'accesstoken')
    accesstokensecret = config.get('twitter', 'accesstokensecret')

    # Comentei esta forma de autenticação, pois a OAuthHandler é capois de obter um numero maior de requisições a api search
    # auth = tw.OAuthHandler(consumerkey,consumersecret)
    # auth.set_access_token(access_token, accesstokensecret )
    # api = tw.API(auth,wait_on_rate_limit=True)

    auth = tw.AppAuthHandler(consumerkey, consumersecret)
    api = tw.API(auth,
                 wait_on_rate_limit=True  # Se deve ou não esperar automaticamente a reposição dos limites de taxa
                 , wait_on_rate_limit_notify=True
                 # Se deve ou não imprimir uma notificação quando o Tweepy aguarda a reposição dos limites de taxa
                 )
    return api


def get_tweets(search_words, since_id=None, max_id=None, total_tweets=100):
    api = get_tweepy_api_conected()

    # max_id & since_id que servem como limites superior e inferior dos códigos únicos que o Twitter atribui a cada tweet
    # q[, geocode][, lang][, locale][, result_type][, count][, until][, since_id][, max_id][, include_entities]
    # http://docs.tweepy.org/en/latest/api.html#API.search
    lista = []
    tweets = tw.Cursor(api.search,
                       q=search_words,
                       count=100, # O número de tweets a serem retornados por página, até um máximo de 100. O padrão é 15.
                       # until=date_until,
                       since_id=since_id,
                       max_id=max_id,
                       result_type="mixed",  # popular , mixed , recent
                       tweet_mode="extended"
                       # Impede que o texto do tweet seja truncado. Neste caso a propriedade "text" será substituida pela  "full_text" no json de retorno.
                       ).items(
        total_tweets)  # Quantos tweets eu desejo buscar. (Existe o limite de 450 chamadas a cada 15 min. cada chamada recupera até 100 tweets ) https://developer.twitter.com/en/docs/twitter-api/v1/tweets/search/api-reference/get-search-tweets

    for t in tweets:
        lista.append(t)

    logging.info('Parametro total_tweets:{}, Recuperados:{}'.format(total_tweets, len(lista)))
    time.sleep(1)

    return lista;

def get_tweets_by_ids(id_, api):

    lista = []
    #tweets = api.statuses_lookup(id_[, include_entities][, trim_user][, map_][, include_ext_alt_text][, include_card_uri])
    tweets = api.statuses_lookup(id_=id_, tweet_mode='extended')

    for t in tweets:
        lista.append(t)

    print('Recuperados:{}'.format(len(lista)))
    time.sleep(1)

    return lista;

def get_tweets_by_ids(id_, api):

    lista = []
    #tweets = api.statuses_lookup(id_[, include_entities][, trim_user][, map_][, include_ext_alt_text][, include_card_uri])
    tweets = api.statuses_lookup(id_=id_, tweet_mode='extended')

    for t in tweets:
        lista.append(t)

    print('Recuperados:{}'.format(len(lista)))
    time.sleep(1)

    return lista;

def get_tweets_by_id(id):

    api = get_tweepy_api_conected()

    lista = []
    #tweets = api.get_status(id[, trim_user][, include_my_retweet][, include_entities][, include_ext_alt_text][, include_card_uri])
    tweet = api.get_status(id, trim_user=False, include_entities=True, include_card_uri= False  )

    return [tweet];


def get_tweets_por_dia(search_words="", since_id=None, max_id=None, dt_start="", dt_end="", total_tweets_dia=100):
    start_date = datetime.strptime(dt_start, "%d/%m/%Y")
    end_date = datetime.strptime(dt_end, "%d/%m/%Y")

    datas = [start_date]
    while True:
        if datas[-1] == end_date:
            break
        datas.append(datas[-1] + timedelta(days=1))

    lista = []
    for d in datas:
        dt_ini = d.strftime("%Y-%m-%d")
        dt_fim = (d + timedelta(days=1)).strftime("%Y-%m-%d")

        str_search = search_words + " since:{} until:{}".format(dt_ini, dt_fim)
        logging.info('Buscando search_words =' + str_search)
        logging.info('Data:  since:{} until:{}'.format(dt_ini, dt_fim))
        logging.info('-----------------------------------------------------------------------------')
        time.sleep(5)
        tweets = get_tweets(search_words=str_search, since_id=since_id, max_id=max_id, total_tweets = total_tweets_dia)
        for t in tweets:
            lista.append(t)
    return lista


def parse_tweet_to_array(tweets):
    '''for t in tweets:
        t.full_text = t.full_text +" #ABC" '''

    tz = pytz.timezone('America/Sao_Paulo')

    tweet_details = [{
        'id': tweet.id_str,
        'origem': tweet.user.screen_name,
        'destino': identificar_vertice_target(remover_break_lines(tweet.full_text), tweet.user.screen_name),
        'relacionamento': indentificar_relacionamento2(tweet),
        'sentimento': polarity_scores(limpar_texto(tweet.full_text_en), True) if hasattr(tweet, 'full_text_en') else "",
        #'texto':  tweet.full_text,
        'texto':  get_full_text(tweet),
        #'texto_limpo': limpar_texto(tweet.full_text),
        'texto_limpo': limpar_texto(get_full_text(tweet)),
        'texto_en_limpo':'',# limpar_texto(tweet.full_text_en) if hasattr(tweet, 'full_text_en') else "",
        'created_at': pytz.utc.localize(tweet.created_at).astimezone(tz),
        'dt_insert_utc': datetime.now(pytz.utc),
        'link': "https://twitter.com/{}/status/{}".format(tweet.user.screen_name, tweet.id_str),
        'entities': tweet.entities,
        'favorite_count': tweet.favorite_count,
        'retweet_count': tweet.retweet_count,
        'reply_count': None,
        'hashtags': str(json.dumps(tweet.entities['hashtags'])),
        'tweet_original': (json.dumps(tweet._json,ensure_ascii=False).encode('utf8')).decode() #str(json.dumps(tweet._json))
    } for tweet in tweets]

    return tweet_details




def remover_break_lines(text):
    text = re.sub("\n", " ", text)
    return text


def limpar_texto_OLD(text):
    text = remover_break_lines(text)
    text = re.sub(r'@[A-Za-z0-9]+', '', text)  # remover @mentions
    text = re.sub(r'#', "", text)  # Remover símbolo '#'
    text = re.sub(r'RT[\s]+', '', text)  # Remover RT
    text = re.sub(r'https?:\/\/\S+', '', text)  # Remover hyperlinks

    return text



def get_stopwords(text, idioma):
    #idioma = 'portuguese'
    #idioma = 'english'
    tokens = nltk.tokenize.word_tokenize(text)
    stopwords = nltk.corpus.stopwords.words(idioma)
    stopwords_encontradas_no_texto = [w for w in tokens if w.lower() in stopwords]
    return stopwords_encontradas_no_texto

def filtrar_tweets_invalidos(tweets_):
    tweets = []
    achou = False
    for t in tweets_:
        texto = limpar_texto(remover_break_lines(t.full_text))
        if len(texto.replace(" ", '')) != 0:
            tweets.append(t)
        else:
            print("Tweet descartado: https://twitter.com/{}/status/{} - Texto:{}".format(t.user.screen_name, t.id_str,
                                                                                         t.full_text))
    return tweets


def tokenize_sentences(text, idioma='portuguese'):
    sentences_tokens = nltk.tokenize.sent_tokenize(text, idioma)
    return sentences_tokens


def tokenize_words(text, idioma='portuguese'):
    tokens = nltk.tokenize.word_tokenize(text, idioma)
    return tokens


def identificar_entidades(text):
    return [(ent.text, ent.label_) if (not ent.text.startswith('#')) else "" for ent in nlp(text).ents]


def extractNounsAndVerbsAndAdjectves(text, idioma='portuguese'):
    text = nltk.word_tokenize(text, idioma)
    pos_tagged = nltk.pos_tag(text)
    # https://pythonprogramming.net/sentiment-analysis-python-textblob-vader/
    nouns = filter(lambda x: (x[1] == 'NN') or (x[1] == 'VB') or (x[1] == 'JJ'), pos_tagged)
    nouns = [x[0] for x in nouns]
    return nouns


def indentificar_relacionamento(text):
    text = text.strip() # removo espaços nas estremidades de text
    if (text[:3] == "RT "):
        return "retweet"
    elif (text[:1] == "@"):
        return "responde"
    else:
        return "tweet"


def indentificar_relacionamento2(tweet):
    if hasattr(tweet, 'retweeted_status'):
        return 'retweet'
    if tweet.in_reply_to_screen_name is not None:
        return 'responde'
    return "tweet"

def get_full_text(tweet):

    if hasattr(tweet, 'retweeted_status'):
        return str(tweet._json.get("retweeted_status").get("full_text"))
    else:
        return tweet.full_text





def identificar_vertice_target(text, autor):
    text = text.strip()
    rel = indentificar_relacionamento(text)
    if (rel == "tweet"):
        return autor
    elif (rel == "retweet"):
        v2 = text.split(":")[0].replace("RT @", "")
        return v2
    elif (rel == "responde"):
        v2 = text.split("@")[1].split(" ")[0]
        return v2
    elif (rel == "menciona"):
        v2 = text.split("@")[1].split(" ")[0]
        return v2
    else:
        return ""


def polarity_to_categ_and_subcateg(polarity):
    if polarity == 0:
        return polarity, "NEU", ""
    elif 0 < polarity <= 0.3:
        return polarity, "POS", "Positivo Fraco"
    elif 0.3 < polarity <= 0.6:
        return polarity, "POS", "Positivo Médio"
    elif 0.6 < polarity <= 1.0:
        return polarity, "POS", "Positivo Forte"
    elif -0.3 <= polarity < 0:
        return polarity, "NEG", "Negativo Fraco"
    elif -0.6 <= polarity < -0.3:
        return polarity, "NEG", "Negativo Médio"
    elif -1.0 <= polarity < -0.6:
        return polarity, "NEG", "Negativo Forte"
    return polarity, "", "",


def subjectivity_to_categ(subjectivity):
    if (subjectivity <= 0.3):
        return "Fraca"
    elif (intensity > 0.3 and intensity <= 0.6):
        return "Média"
    elif (intensity > 0.6 and intensity <= 1.0):
        return "Forte"





def compoundToCategAndSubCateg_OLD(compound):

    if (compound == 0):
        return compound, "NEU", ""
    elif (compound > 0 and compound <= 0.3):
        return compound, "POS", "Positivo Fraco" #"Weak Positive"
    elif (compound > 0.3 and compound <= 0.6):
        return compound, "POS", "Positivo Médio" #"Medium Positive"
    elif (compound > 0.6 and compound <= 1.0):
        return compound, "POS", "Positivo Forte" #"Strong Positive"
    elif (compound >= -0.3 and compound < 0):
        return compound, "NEG", "Negativo Fraco"#"Weak Negative"
    elif (compound >= -0.6 and compound < -0.3):
        return compound, "NEG", "Negativo Médio" #"Medium Negative"
    elif (compound >= -1.0 and compound < -0.6):
        return compound, "NEG", "Negativo Forte" #"Strong Negative"
    return compound, "", "",

#x =  np.arange(-1.00, 1.01, 0.01)
#for n in x:
#  print(intensity_to_categ_and_subcateg(round(n,2)))


def polarity_scores_categ_and_subcateg_lwic(text_pt):
    return None;


'''def filtrarPalavasMaisFrequentes(list_of_words, max):
    mais_comuns = obterFrequencias(list_of_words, max)
    top_words = [i[0] for i in mais_comuns]
    return top_words'''


def obterFrequencia(list_of_words, max):
    top_words = []
    if isinstance(list_of_words[0], tuple):
        for i in range(max):
            top_words.append(list_of_words[i])
    else:
        counter = collections.Counter(list_of_words)  # Conta a frequencia
        mais_comuns = counter.most_common(max)  # retorna uma lista com as mais frequentes
        top_words = [i for i in mais_comuns]

    # g_df = pd.DataFrame(data=top_words, columns=["Palavra", "Frequência"])
    # arquivoHtml = './resources/coletas_twipy/nuvens_de_palavras{}.html'.format(randomString())
    # print("arquivoHtml: " + arquivoHtml)
    # print(tabulate(g_df, headers='keys', tablefmt='grid'))
    # g_df.to_html(arquivoHtml)
    return top_words


def filtrarPalavrasPositivasENegativasEFrequencia(tweet_details, idioma='portuguese'):
    corpus = ""
    for v in tweet_details:
        if idioma == 'portuguese':
            texto = v['texto_limpo']
        else:
            texto = v['texto_en_limpo']
        texto_sem_stopwords = remover_stopwords(texto, idioma)
        corpus = corpus + ' ' + texto_sem_stopwords

    nounsAndVebs = extractNounsAndVerbsAndAdjectves(corpus)

    top_words = obterFrequencia(nounsAndVebs, 1000)

    # corpus = ' '.join(top_words)

    # tokenized_sentence = nltk.word_tokenize(corpus)
    pos_word_list = []
    neu_word_list = []
    neg_word_list = []

    for i in range(len(top_words)):
        word = top_words[i][0]
        if (polarity_scores(word, sumarizado=True)) == 'POS':
            pos_word_list.append(top_words[i])
        elif (polarity_scores(word, sumarizado=True)) == 'NEG':
            neg_word_list.append(top_words[i])
        else:
            neu_word_list.append(top_words[i])

    retorno = {'POS': pos_word_list, 'NEU': neu_word_list, 'NEG': neg_word_list}
    return retorno


def plotar_word_clod(text, max_words=50, mask_image=None):
    texto = remover_stopwords(text)
    # texto = nltk.tokenize.word_tokenize(text, "portuguese")
    stopwordsPt = nltk.corpus.stopwords.words('portuguese')

    mask = None
    if not (mask_image is None):
        mask = np.array(Image.open(os.path.join(mask_image)))

    # max_words = 50
    wc = WordCloud(background_color="white", stopwords=stopwordsPt, max_words=max_words, mask=mask, contour_width=1,
                   contour_color='black')
    wc.generate(texto)

    # show
    plt.imshow(wc, interpolation='bilinear')
    plt.axis("off")
    plt.show()


def get_hashtags_por_data(tweets):
    hashtags = []
    for t in tweets:
        if not (t['entities']['hashtags'] is None):
            for h in t['entities']['hashtags']:
                hashtags.append(h['text'].upper())

    counter = collections.Counter(hashtags)  # Conta a frequencia
    print("counter: {}", counter)
    hashtags_mais_comuns = counter.most_common(5)  # retorna uma lista com as mais frequentes
    print("hashtags_mais_comuns: {}", hashtags_mais_comuns)
    top_hashtags = [i[0] for i in hashtags_mais_comuns]
    dic_frequencia_por_hashtag = {}
    for i in hashtags_mais_comuns:
        dic_frequencia_por_hashtag[i[0]] = i[1]
    print("dic_frequencia_por_hashtag: {}".format(dic_frequencia_por_hashtag))

    hashtags_por_data = []
    for t in tweets:
        if not (t['entities']['hashtags'] is None):
            for h in t['entities']['hashtags']:
                if h['text'].upper() in top_hashtags:
                    hashtag_label = "#{} - Qtd:({})".format(h['text'].upper(),
                                                            dic_frequencia_por_hashtag[h['text'].upper()])
                    hashtags_por_data.append(
                        {"created_at": t['created_at'].replace(hour=0, minute=0, second=0, microsecond=0),
                         "hashtag": hashtag_label})
    print(hashtags_por_data)

    return hashtags_por_data


def plotar_chart_hashtags_por_dia(tweets):
    hashtags_por_data = get_hashtags_por_data(tweets)

    if len(hashtags_por_data) > 0:

        h_df = pd.DataFrame(hashtags_por_data, columns=['created_at', 'hashtag'])

        h_df['created_at'] = h_df['created_at'].dt.floor('d')
        h_df = h_df.groupby('created_at')['hashtag'].value_counts().unstack().fillna(0).reset_index()
        print(tabulate(h_df, headers='keys', tablefmt='grid'))

        x_values = h_df['created_at'].tolist()
        ax = plt.gca()
        formatter = mdates.DateFormatter("%Y-%m-%d")
        ax.xaxis.set_major_formatter(formatter)
        ax.grid(True)
        locator = mdates.DayLocator()
        ax.xaxis.set_major_locator(locator)
        for col in h_df.columns:
            if col != "created_at":
                plt.plot(x_values, h_df[col].tolist(), label=col)
                for a, b in zip(x_values, h_df[col].tolist()):
                    plt.text(a, b, str(b))
        plt.legend()
        plt.title('Hashtags por Dia (Top 5)')
        plt.ylabel('Qtd')
        plt.xlabel('Data de Publicação')
        plt.show()


def plotar_chart_sentimentos_por_dia(tweets):
    # https://pandas.pydata.org/pandas-docs/stable/user_guide/visualization.html

    g_df = pd.DataFrame(data=tweets, columns=["created_at", "sentimento"])
    g_df['created_at'] = g_df['created_at'].dt.floor('d')
    g_df = g_df.groupby('created_at')['sentimento'].value_counts().unstack().fillna(0).reset_index()
    print(tabulate(g_df, headers='keys', tablefmt='grid'))
    g_df.to_html('./resources/coletas_twipy/sentimentos_por_dia_df.html')

    x_values = g_df['created_at'].tolist()
    ax = plt.gca()
    formatter = mdates.DateFormatter("%Y-%m-%d")
    ax.xaxis.set_major_formatter(formatter)
    ax.grid(True)
    locator = mdates.DayLocator()
    ax.xaxis.set_major_locator(locator)
    for col in g_df.columns:
        if col != "created_at":
            plt.plot(x_values, g_df[col].tolist(), label=col)
            for a, b in zip(x_values, g_df[col].tolist()):
                plt.text(a, b, str(b))
    plt.legend()
    plt.title('Sentimento por Dia')
    plt.ylabel('Qtd. Tweets')
    plt.xlabel('Data de Publicação')
    plt.show()


def randomString(stringLength=8):
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(stringLength))

# https://pythex.org/ (Regex playgound)
def limpar_texto(text):
    text = remover_break_lines(text)
    text = re.sub(r'^RT \S+ ', '', text)  # remover marca de retweet
    text = re.sub(r'@\S+', '', text)  # remover @mentions
    text = re.sub(r'#\S+', '', text)  # remover hashtags
    text = re.sub(r' +', ' ', text)  # troco qualquer número de espaços por 1 espaço
    text = re.sub(r'https?:\/\/\S+', '', text)  # Remover hyperlinks
    text = text.strip()
    return text






# print(limpar_texto("RT @ifbeaus: eu te amo cabelo do joshua https://t.co/ioD3U7iafI"))

'''

#print(SentimentIntensityAnalyzer().lexicon)
sid = SentimentIntensityAnalyzer()
tweet = "\"We will defeat Bolsonaro on 22.\"People on the electoral left and liberals act as common in one of…"

tweet = "Catch utf-8 emoji such as 💘 and 💋 and 😁"
print(tweet)
print(sid.polarity_scores(tweet))

cat, scat = polarity_scores_categ_and_subcateg(tweet)
print(cat, scat)
'''



