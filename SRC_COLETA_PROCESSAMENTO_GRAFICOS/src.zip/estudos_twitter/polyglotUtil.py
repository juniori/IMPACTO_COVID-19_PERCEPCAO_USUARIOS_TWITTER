#https://textblob.readthedocs.io/en/dev/quickstart.html#sentiment-analysis
#https://pypi.org/project/polyglot/

# ##############################
# Dica de Instalação: https://stackoverflow.com/questions/53760587/polyglot-installation
# Para meu caso, paython 3.8.3, Baixar os arquivos abaixo em: https://www.lfd.uci.edu/~gohlke/pythonlibs/
# pip install C:\Users\junior\Downloads\pycld2-0.41-cp38-cp38-win_amd64.whl
# pip install C:\Users\junior\Downloads\PyICU-2.9-cp38-cp38-win_amd64.whl
# pip install git+https://github.com/aboSamoor/polyglot@master
# ##############################

from polyglot.downloader import downloader
from polyglot.text import Text
import twipyUtil as twipyUtil
from textblob import TextBlob
import statistics

# polyglot download sentiment2.en (executar no terminal)
# polyglot download sentiment2.pt (executar no terminal)
# Os pacotes são baixado em "C:\Users\junior\AppData\Roaming\polyglot_data"

# print(downloader.supported_languages_table("sentiment2", 3)) # printa as linguas suportadas

#downloader.list(show_packages=False) # Lista todas as coleções ou pacotes disponíveis e/ou instalados
'''
def print_polaridade_por_palavra(text):
  print("{:<16}{}".format("Word", "Polarity")+"\n"+"-"*30)
  for w in text.words:
    print("{:<16}{:>2}".format(w, w.polarity))

frase_pt = "Bolsonaro vai levar a compra da vacina em banho maria. A pandemia veio para afetar a economia e matar os mais vulneráveis, e a única medida do Bolsonaro é ir a praia, falsificar cartão de vacinação da mãe e sorrir para seu rebanho."
frase_en = "Bolsonaro will bring the purchase of the vaccine in a water bath.The pandemic came to affect the economy and kill the most vulnerable, and Bolsonaro's only measure is to go to the beach, falsify his mother's vaccination card and smile at his flock."

print("polyglot EN-------------------")
text = Text(frase_en)
text.language = 'en'
print(text.polarity)
print_polaridade_por_palavra(text)

print("polyglot PT-------------------")
text = Text(frase_pt)
text.language = 'pt'
print(text.polarity)
print_polaridade_por_palavra(text)

print("VADER EN -------------------")
print("Vader", twipyUtil.vader_polarity_scores(frase_en)['compound'])


print("TEXTBLOB EN -------------------")
testimonial = TextBlob(frase_en)
print(testimonial.sentiment.polarity)
'''

'''
for sent in text.sentences:
  print(sent.entities, sent);



for sent in text.sentences:
  for ent in sent.entities:
    print("{}- {} --> Neg:{}, Pos:{}".format(sent, ent, ent.negative_sentiment, ent.positive_sentiment) );

'''

IDIOMA_EN = 'en'
IDIOMA_PT = 'pt'

def polyglot_polarity_scores_categ_and_subcateg(texto, idioma,  print_words = False):
  if idioma == 'portuguese':
    idioma = IDIOMA_PT
  elif idioma == 'english':
    idioma = IDIOMA_EN

  if idioma not in ('pt', 'en'):
    raise Exception("O idioma informado é inválido: " + idioma)


  #IDIOMA_EN = 'en'
  #IDIOMA_PT = 'pt'
  text = Text(texto)
  text.language = idioma
  compound = text.polarity

  if print_words:
    for w in text.words:
      print("{:<16}{:>2}".format(w, w.polarity))

  return twipyUtil.polarity_to_categ_and_subcateg(compound)

'''
frase_pt = "Bolsonaro vai levar a compra da vacina em banho maria. A pandemia veio para afetar a economia e matar os mais vulneráveis, e a única medida do Bolsonaro é ir a praia, falsificar cartão de vacinação da mãe e sorrir para seu rebanho."
#frase_pt = "matar"
frase_en = "Bolsonaro will bring the purchase of the vaccine in a water bath.The pandemic came to affect the economy and kill the most vulnerable, and Bolsonaro's only measure is to go to the beach, falsify his mother's vaccination card and smile at his flock."


print(polyglot_polarity_scores_categ_and_subcateg(frase_en, IDIOMA_EN));
print(polyglot_polarity_scores_categ_and_subcateg(frase_pt, IDIOMA_PT));

'''
#termo = 'Pra FOLHA falar em "baixa adesão" contra Bolsonaro, é porque o negócio foi ruim, mas ruim, ruim, ruim, ruim...'

print(polyglot_polarity_scores_categ_and_subcateg("morte", IDIOMA_PT));