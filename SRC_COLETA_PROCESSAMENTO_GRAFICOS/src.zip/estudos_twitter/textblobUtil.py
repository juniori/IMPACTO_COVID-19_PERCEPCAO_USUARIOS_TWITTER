# https://textblob.readthedocs.io/en/dev/quickstart.html#sentiment-analysis

from textblob import TextBlob
import twipyUtil as twipyUtil


def textblob_polarity_scores_categ_and_subcateg(texto_en):
    blob = TextBlob(texto_en)
    compound = blob.sentiment.polarity
    subjetividade = blob.sentiment.subjectivity
    sent_tb_compound, sent_tb_categ, sent_tb_subcateg = twipyUtil.polarity_to_categ_and_subcateg(compound)

    return sent_tb_compound, sent_tb_categ, sent_tb_subcateg, subjetividade


print(textblob_polarity_scores_categ_and_subcateg("I like banana"));
