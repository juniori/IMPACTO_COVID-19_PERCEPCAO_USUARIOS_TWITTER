# ##########################################################
# Tweets - User Timeline API
# Recuperar tweets e retweets de um usuário
# Referências:
# https://docs.tweepy.org/en/latest/api.html#tweepy.API.user_timeline
# https://developer.twitter.com/en/docs/twitter-api/v1/tweets/timelines/api-reference/get-statuses-user_timeline
# ##########################################################
import logging
logging.basicConfig(level=logging.INFO)


import twipyUtil as util
import dbUtil as dbUtil
import tweepy as tw
import time
import pandas as pd
import sys as sys
from datetime import datetime
import tradutorUtil as tradutor
import sys
tw.debug(False)


base_path = "C:/Users/junior/Google Drive/_Mestrado/SEAN/Dissertacao_Celso/resources/datasets/"
tweets_elegiveis_traducao = base_path+"tweets_elegiveis_traducao.csv"

df = pd.read_csv(tweets_elegiveis_traducao)
df.fillna('', inplace=True)
df = df.astype(str) # Converto todas as colunas para string

tweets_a_processar =  df.to_dict('records')


def create_chunks(list_name, n):
    for i in range(0, len(list_name), n):
        yield list_name[i:i + n]

#autor = '__amarcella'
#tweet_details = dbUtil.getFromDataBase("dataset_tweets_bert_timeline_1", "where origem='"+autor+"' and (texto_en_limpo = '' or (texto_en_limpo <> '' and texto_limpo = texto_en_limpo)) and (flag <> 'B' and (upper(texto_limpo ) like '%BOLSONARO%' or upper(texto_limpo ) like '%GOVERNO%'))")

print("Tweets do usuário a processar:{}".format(len(tweets_a_processar))) 

#tweets_a_processar = tweets_a_processar[:300]

k = 15 # Salvar de k am k itens

chunks = create_chunks(tweets_a_processar, k)

#chunks = [[{'texto_limpo':'MAIS 2 DISCURSO DO LULA O Adalberto JÁ VAI ESTAR POSTANDO NO TWITTER: "BOM DIA A TODES"'}]]

for i in chunks:
    try:

        tweets = tradutor.traduzir_tweet_pt_to_en3(i)

        dbUtil.update_texto_en("dataset_tweets_base_2021_hiccs_manual", tweets)
        print("processados:{} - Origem:{}".format(len(tweets), i[0]["origem"]))
    except Exception as e:
        print("erro na tradução:{}".format(e))

