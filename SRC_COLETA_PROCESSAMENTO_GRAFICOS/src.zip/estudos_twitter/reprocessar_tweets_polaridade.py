# ##########################################################
# Tweets - User Timeline API
# Recuperar tweets e retweets de um usuário
# Referências:
# https://docs.tweepy.org/en/latest/api.html#tweepy.API.user_timeline
# https://developer.twitter.com/en/docs/twitter-api/v1/tweets/timelines/api-reference/get-statuses-user_timeline
# ##########################################################
import logging
logging.basicConfig(level=logging.INFO)


import twipyUtil as util
import dbUtil as dbUtil
import textoUtil as textoUtil
import tweepy as tw
import time
import pandas as pd
import sys as sys
from datetime import datetime
import tradutorUtil as tradutor
import sys
import twipyUtil as twipyUtil
import vaderUtil as vaderUtil
import polyglotUtil as polyglotUtil
import textblobUtil as textblobtUtil
from textblob import TextBlob
tw.debug(False)


base_path = "C:/Users/junior/Google Drive/_Mestrado/SEAN/Dissertacao_Celso/resources/datasets/"
tweets_elegiveis_polaridade = base_path+"tweets_elegiveis_polaridade.csv"

df = pd.read_csv(tweets_elegiveis_polaridade)
df.fillna('', inplace=True)
df = df.astype(str) # Converto todas as colunas para string


usuarios_unicos = df['origem'].unique();

# sent_vader_compound, sent_vader_categ, sent_vader_subcateg, sent_textblob_polaridade, sent_textblob_subjetividade
for index_usuario, u in enumerate(usuarios_unicos):

    df_usuario = df[df['origem'] == u]

    for index, t in df_usuario.iterrows():


        texto_en_limpo = t['texto_en_limpo']
        # print("antes", texto_en_limpo)
        texto_en_limpo = textoUtil.remover_stopwords(texto_en_limpo, "english")
        #texto_en_limpo = textoUtil.lemma(texto_en_limpo, "english",   excluir=['NUM', 'SPACE', 'PUNCT'], lematizar=[])


        # print("depois", texto_en_limpo)
        # print("----------------------------------------------------------------")

        texto_limpo = t['texto_limpo']
        # print("antes PT", texto_limpo)
        texto_limpo = textoUtil.remover_stopwords(texto_limpo, "portuguese")
        #texto_limpo = textoUtil.lemma(texto_limpo, "portuguese", excluir=['NUM', 'SPACE', 'PUNCT'], lematizar=[])
        # print("depois PT", texto_limpo)
        # print("=====================================================")

        if (not texto_en_limpo) or (not texto_limpo):
            print('id', t['id'])
            print("pulou string vazia depois de remover stopwords")
            print('texto_en_limpo', t['texto_en_limpo'])
            print('texto_limpo', t['texto_limpo'])
            continue;

        sent_vader_compound, sent_vader_categ, sent_vader_subcateg = vaderUtil.vader_polarity_scores_categ_and_subcateg(texto_en_limpo)

        sent_poli_compound, sent_poli_categ, sent_poli_subcateg = polyglotUtil.polyglot_polarity_scores_categ_and_subcateg(texto_en_limpo, polyglotUtil.IDIOMA_EN )
        sent_poliPT_compound, sent_poliPT_categ, sent_poliPT_subcateg = polyglotUtil.polyglot_polarity_scores_categ_and_subcateg(texto_limpo, polyglotUtil.IDIOMA_PT)

        sent_tb_compound, sent_tb_categ, sent_tb_subcateg, sent_tb_subjetividade = textblobtUtil.textblob_polarity_scores_categ_and_subcateg(texto_en_limpo)


        '''
        print(t['texto_limpo'])
        print("- - - - - - - - - - - - - - - - ")
        print('Texto pt avaliado: ', texto_limpo)
        print("- - - - - - - - - - - - - - - - ")
        print('Texto en avaliado: ', texto_en_limpo)
        print("- - - - - - - - - - - - - - - - ")
        print('Vade',sent_vader_compound, sent_vader_categ, sent_vader_subcateg);
        print('Plig', sent_poli_compound, sent_poli_categ, sent_poli_subcateg );
        print('PoPT', sent_poliPT_compound, sent_poliPT_categ, sent_poliPT_subcateg );
        print('text', sent_tb_compound, sent_tb_categ, sent_tb_subcateg, sent_tb_subjetividade);
        '''

        #atualizar sentimento na base de dados
        dbUtil.update_sentimento("dataset_tweets_base_2021_timeline_30dias_gov_origens_tweets_swo", t['id'],
                                 sent_vader_compound, sent_vader_categ, sent_vader_subcateg,
                                 sent_poli_compound, sent_poli_categ, sent_poli_subcateg,
                                 sent_poliPT_compound, sent_poliPT_categ, sent_poliPT_subcateg,
                                 sent_tb_compound, sent_tb_categ, sent_tb_subcateg, sent_tb_subjetividade);

    print ("Usuário processado:{}, Usuário:{} de {}".format(u, index_usuario+1, len(usuarios_unicos)))

