from psycopg2 import extras
import psycopg2
import json
from datetime import datetime, timedelta
import pytz  # timezone

# Open a DB session

def getConnection():
    dbSession = psycopg2.connect("dbname='redes_sociais' user='postgres' password='junior01'");
    return dbSession

def addToDatabase(tweet_details, table_name, search_words, flag, isInsertOrReplace=False):
    #https://stackoverflow.com/questions/8134602/psycopg2-insert-multiple-rows-with-one-query
    conn = getConnection()
    cursor = conn.cursor();
    data = []
    for v in tweet_details:
        data.append((
                        v['id'],
                        v['origem'],
                        v['destino'],
                        v['relacionamento'],
                        v['sentimento'],
                        v['texto'],
                        v['texto_limpo'],
                        v['texto_en_limpo'],
                        v['created_at'],
                        v['dt_insert_utc'],
                        None, #str(json.dumps(v['entities'])),
                        v['favorite_count'],
                        v['retweet_count'],
                        v['reply_count'],
                        None,#v['hashtags'],
                        None,#v['tweet_original'],
                        v['link'],
                        search_words,
                        flag


        ))

    #data = [(1,'x'), (2,'y')]
    records_list_template = ','.join(['%s'] * len(data))

    on_conflict = 'DO NOTHING'
    if flag == 'sntwitter':
        on_conflict = 'DO UPDATE SET reply_count = excluded.reply_count'
    elif isInsertOrReplace:
        on_conflict = '''DO UPDATE SET
        origem = excluded.origem,
        destino = excluded.destino,
        relacionamento = excluded.relacionamento,
        sentimento = excluded.sentimento,
        texto = excluded.texto,
        texto_limpo = excluded.texto_limpo,
        texto_en_limpo = excluded.texto_en_limpo,
        created_at = excluded.created_at,
        entities = excluded.entities,
        tweet_original = excluded.tweet_original,
        link = excluded.link,
        termo_busca = excluded.termo_busca,
        flag = excluded.flag,
        sent_vader_compound = excluded.sent_vader_compound,
        sent_vader_subcateg = excluded.sent_vader_subcateg,
        sent_vader_categ = excluded.sent_vader_categ,
        sent_textblob_polaridade = excluded.sent_textblob_polaridade,
        sent_textblob_subjetividade = excluded.sent_textblob_subjetividade,
        favorite_count = excluded.favorite_count,
        hashtags = excluded.hashtags,
        retweet_count = excluded.retweet_count,
        reply_count = excluded.reply_count,
        evento = excluded.evento,
        dt_update =excluded.dt_insert_utc'''

    on_conflict = 'DO NOTHING'

    insert_query = ('insert into ' + table_name + ' (id, origem, destino, relacionamento, sentimento, texto, texto_limpo, texto_en_limpo, created_at, dt_insert_utc,entities, favorite_count, retweet_count,reply_count, hashtags, tweet_original,link, termo_busca, flag) values {} ON CONFLICT (id) ' + on_conflict).format(records_list_template)
    cursor.execute(insert_query, data)
    conn.commit()
    #print(data)


def addToDatabase_Tweets_hicss_manual(tweet_details, table_name, search_words, flag, isInsertOrReplace=False):

    conn = getConnection()
    cursor = conn.cursor();
    data = []
    for v in tweet_details:
        data.append((
                        v['id'],
                        v['origem'],
                        v['destino'],
                        v['relacionamento'],
                        v['sentimento'],
                        v['texto'],
                        v['texto_limpo'],
                        v['texto_en_limpo'],
                        v['created_at'],
                        v['dt_insert_utc'],
                        str(json.dumps(v['entities'])),
                        v['favorite_count'],
                        v['retweet_count'],
                        v['reply_count'],
                        v['hashtags'],
                        v['tweet_original'],
                        v['link'],
                        search_words,
                        flag


        ))

    #data = [(1,'x'), (2,'y')]
    records_list_template = ','.join(['%s'] * len(data))

    on_conflict = 'DO NOTHING'
    if flag == 'sntwitter':
        on_conflict = 'DO UPDATE SET reply_count = excluded.reply_count'
    elif isInsertOrReplace:
        on_conflict = '''DO UPDATE SET
        origem = excluded.origem,
        destino = excluded.destino,
        relacionamento = excluded.relacionamento,
        sentimento = excluded.sentimento,
        texto = excluded.texto,
        texto_limpo = excluded.texto_limpo,
        texto_en_limpo = excluded.texto_en_limpo,
        created_at = excluded.created_at,
        entities = excluded.entities,
        tweet_original = excluded.tweet_original,
        link = excluded.link,
        termo_busca = excluded.termo_busca,
        flag = excluded.flag,
        sent_vader_compound = excluded.sent_vader_compound,
        sent_vader_subcateg = excluded.sent_vader_subcateg,
        sent_vader_categ = excluded.sent_vader_categ,
        sent_textblob_polaridade = excluded.sent_textblob_polaridade,
        sent_textblob_subjetividade = excluded.sent_textblob_subjetividade,
        favorite_count = excluded.favorite_count,
        hashtags = excluded.hashtags,
        retweet_count = excluded.retweet_count,
        reply_count = excluded.reply_count,
        evento = excluded.evento,
        dt_update =excluded.dt_insert_utc'''

    on_conflict = 'DO NOTHING'

    insert_query = ('insert into ' + table_name + ' (id, origem, destino, relacionamento, sentimento, texto, texto_limpo, texto_en_limpo, created_at, dt_insert_utc,entities, favorite_count, retweet_count,reply_count, hashtags, tweet_original,link, termo_busca, flag) values {} ON CONFLICT (id) ' + on_conflict).format(records_list_template)
    cursor.execute(insert_query, data)
    conn.commit()
    #print(data)



def update_texto_en(table_name, tweet_details):
    #https://stackoverflow.com/questions/8134602/psycopg2-insert-multiple-rows-with-one-query
    conn = getConnection()
    cursor = conn.cursor();

    for v in tweet_details:
        insert_query = "update " + table_name + " set texto_en_limpo =%s where texto_limpo =%s "
        cursor.execute(insert_query, (v['texto_en_limpo'], v['texto_limpo']))
        conn.commit()

def update_json_tweet_original(table_name, tweet_details):
    conn = getConnection()
    cursor = conn.cursor()

    for v in tweet_details:
        update_query = "update " + table_name + " set tweet_original =%s where id =%s "
        cursor.execute(update_query, (v['tweet_original'], v['id']))
        conn.commit()


def update_sentimento(table_name, tweet_id,
                                 sent_vader_compound, sent_vader_categ, sent_vader_subcateg,
                                 sent_poli_compound, sent_poli_categ, sent_poli_subcateg,
                                 sent_poliPT_compound, sent_poliPT_categ, sent_poliPT_subcateg,
                                 sent_tb_compound, sent_tb_categ, sent_tb_subcateg, sent_tb_subjetividade):
    conn = getConnection()
    cursor = conn.cursor();

    insert_query = "update " + table_name + " set sent_vader_polaridade=%s, sent_vader_categ=%s, sent_vader_subcateg=%s, sent_poli_polaridade=%s, sent_poli_categ=%s, sent_poli_subcateg=%s, sent_poli_polaridade_pt=%s, sent_poli_categ_pt=%s, sent_poli_subcateg_pt=%s, sent_textblob_polaridade=%s, sent_textblob_categ=%s, sent_textblob_subcateg=%s, sent_textblob_subjetividade=%s where id =%s"
    cursor.execute(insert_query, (sent_vader_compound, sent_vader_categ, sent_vader_subcateg,
                                 sent_poli_compound, sent_poli_categ, sent_poli_subcateg,
                                 sent_poliPT_compound, sent_poliPT_categ, sent_poliPT_subcateg,
                                 sent_tb_compound, sent_tb_categ, sent_tb_subcateg, sent_tb_subjetividade, tweet_id))
    conn.commit()

def update_texto_limpo(table_name, tweet_id, texto_limpo ):
    conn = getConnection()
    cursor = conn.cursor();
    query = "update " + table_name + " set texto_limpo =%s where id =%s"
    cursor.execute(query, (texto_limpo, tweet_id))
    conn.commit()

def update_texto_and_texto_limpo(table_name, tweet_details):
    conn = getConnection()
    cursor = conn.cursor();

    for v in tweet_details:
        query = "update " + table_name + " set texto=%s, texto_limpo=%s, rt_updt=%s where id =%s"
        cursor.execute(query, (v['texto'], v['texto_limpo'], 's', v['id']))
        conn.commit()

def update_texto_and_texto_limpo_erro(table_name, ids):
    conn = getConnection()
    cursor = conn.cursor();

    for v in ids:
        query = "update " + table_name + " set rt_updt=%s where id =%s"
        cursor.execute(query, ('e', v))
        conn.commit()

def update_texto_original(table_name, tweet_id, texto):
    conn = getConnection()
    cursor = conn.cursor();
    query = "update " + table_name + " set texto_original =%s, dt_update=%s where id =%s"
    cursor.execute(query, (texto, datetime.now(), tweet_id))
    conn.commit()

def getFromDataBase(tabela, campos="*", where=""):
    conn = getConnection()
    cursor = conn.cursor(cursor_factory = psycopg2.extras.DictCursor)
    query = "select " + campos + "  from " + tabela + " "+where ;
    cursor.execute(query)
    rows = cursor.fetchall()
    dados = []
    for row in rows:
        #row['created_at'] = datetime.strptime(row['created_at'], "%d/%m/%Y")
        dados.append(dict(row))
    return dados

def getByAutor(tabela, autor):
    conn = getConnection()
    cursor = conn.cursor(cursor_factory = psycopg2.extras.DictCursor)
    query = "select *  from " + tabela + " where origem = '{}'".format(autor)
    cursor.execute(query)
    rows = cursor.fetchall()
    dados = []
    for row in rows:
        #row['created_at'] = datetime.strptime(row['created_at'], "%d/%m/%Y")
        dados.append(dict(row))
    return dados

def getById(tabela, id):
    conn = getConnection()
    cursor = conn.cursor(cursor_factory = psycopg2.extras.DictCursor)
    query = "select *  from {} where id = '{}'".format(tabela, id)
    cursor.execute(query)
    row = cursor.fetchone()
    return row

def getMinMaxId(tabela, termo_busca):
    conn = getConnection()
    cursor = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
    sqlSelect = "select min(id) as min_id, max(id) as max_id  from {} where termo_busca = '{}'".format(tabela, termo_busca)
    cursor.execute(sqlSelect);
    row = cursor.fetchone();
    return row['min_id'], row['max_id']

def update_erro_carga_time_line(table_name, origem, erro):
    conn = getConnection()
    cursor = conn.cursor();
    query = "update " + table_name + " set erro_carga =%s where origem =%s"
    cursor.execute(query, (erro, origem))
    conn.commit()

