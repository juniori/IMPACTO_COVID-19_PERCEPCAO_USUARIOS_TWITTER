#https://github.com/JustAnotherArchivist/snscrape

import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] - %(message)s',
    filename='SNSscrapy_Coleta_Tweets_Base.log')

import sys
import snscrape.modules.twitter as sntwitter
import pandas as pd
import json
import twipyUtil as util
import dbUtil as dbUtil
import time
from datetime import datetime, timedelta
import pytz  # timezone

search_words = ''

def getFrases():
    termos = {
        "termos_masc": {
            "pronomes": ["meu"],
            "familiares": ["sobrinho"],
            # "familiares": ["pai", "filho", "irmão", "tio", "primo", "sobrinho", "avô", "parceiro", "amado", "namorado", "companheiro"],
            "verbos": ["morreu de", "faleceu de", "teve", "está com", "pegou", "está internado com", "curou do", "melhorou do", "testou positivo para"],
            "doencas": ["covid", "covid-19", "corona", "corona vírus", "coronavírus"]
        },
        "termos_fem": {
            "pronomes": ["minha"],
            #"familiares": ["mãe", "filha", "irmã", "tia", "prima", "sobrinha", "avó", "parceira", "amada", "namorada", "companheira"],
            "familiares": ["sobrinha"],
            "verbos": ["morreu de", "faleceu de", "teve", "está com", "pegou", "está internada com", "curou do",
                       "melhorou do", "testou positivo para"],
            "doencas": ["covid", "covid-19", "corona", "corona vírus", "coronavírus"]
        }
    }


    frases = []
    for sex, sex_termos in termos.items():
        for tp in sex_termos["pronomes"]:
            for tf in sex_termos["familiares"]:
                #print("select id, origem, created_at, '{}' as parente from dataset_tweets_base where lower(texto) like '%{}%'".format(tp + " " + tf,tp + " " + tf))
                #print("union all")
                for tv in sex_termos["verbos"]:
                    #print("select id, origem, created_at, '{}' as parente from dataset_tweets_base where lower(texto) like '%{}%'".format(tv,tv))
                    #print("union")
                    print("select '2º Semestre' as \"Semestres 2021\", '{}' as acometimento, count(*) qtd from dataset_tweets_base where lower(texto) like '%{}%' and created_at >= '01/07/2021'".format(tv,tv))
                    print("union")
                    for td in sex_termos["doencas"]:
                        frases.append('"' + tp + " " + tf + " " + tv + " " + td + '"');

    return frases;


#getFrases();
#sys.exit();


# Using TwitterSearchScraper to scrape data and append tweets to list
def parse_tweet_snscrape_to_array(tweets):

    tweet_details = [{
        'id': tweet.id,
        'origem': tweet.user.username,
        'destino': util.identificar_vertice_target(tweet.content, tweet.user.username),
        'relacionamento': util.indentificar_relacionamento(tweet.content),
        'sentimento': '', #polarity_scores(limpar_texto(tweet.full_text_en), True) if hasattr(tweet, 'full_text_en') else "",
        'texto': tweet.content,
        'texto_limpo': util.limpar_texto(tweet.content),
        'texto_en_limpo': '', #  limpar_texto(tweet.full_text_en) if hasattr(tweet, 'full_text_en') else "",
        'created_at': tweet.date,
        'dt_insert_utc': datetime.now(pytz.utc),
        'link': tweet.url,
        'entities': '', #tweet.entities,
        'favorite_count': tweet.likeCount,
        'retweet_count': tweet.retweetCount,
        'reply_count': tweet.replyCount,
        'hashtags': None,
        'tweet_original': '{}' # str(json.dumps(tweet._json))
    } for tweet in tweets]

    return tweet_details


#sys.exit()
#assert False, "assert disparado"

#lista_search_words = getFrases();


lista_search_words = ['("meu pai" OR "minha mãe" OR "meu filho" OR "minha filha" OR "meu tio" OR "minha tia" OR "meu avô" OR "minha avó" OR "meu irmão" OR "minha irmã" OR "meu primo" OR "minha prima" OR "meu sobrinho" OR "minha sobrinha" ) AND (morreu OR faleceu OR teve OR pegou OR internado OR curou OR curado OR melhorou OR "teve alta" OR "recebeu alta") AND (corona OR coronavírus OR "corona vírus" OR covid OR covid-19)']

logging.info("lista_search_words:{}".format(len(lista_search_words)));


for search_words in lista_search_words:

    search_words += ' since:2021-01-01 until:2022-01-01 lang:pt'
    logging.info("search_words:{}".format(search_words));
    print("search_words:{}".format(search_words));

    tweets_list2 = []

    for i, tweet in enumerate(sntwitter.TwitterSearchScraper(search_words).get_items()):
        try:
            tweets_list2.append(tweet)
            if (i % 100) == 0:
                print("Salvando ... ", i)
                tweet_details = parse_tweet_snscrape_to_array(tweets_list2)

                print("tweet_details", len(tweet_details));
                dbUtil.addToDatabase(tweet_details, 'dataset_tweets_base_2021', search_words, 'sntwitter')
                tweets_list2 = []
            if i > 100000:
                break;
        except:
            logging.info("ERRO ****************** search_words:", search_words);

    # Gravado os últimos 100 registros
    tweet_details = parse_tweet_snscrape_to_array(tweets_list2)
    print("len(tweet_details)", len(tweet_details))
    if len(tweet_details) > 0:
        dbUtil.addToDatabase(tweet_details, 'dataset_tweets_base_2021', search_words, 'sntwitter')
    tweets_list2 = []





# Creating a dataframe from the tweets list above
#tweets_df2 = pd.DataFrame(tweets_list2, columns=['Datetime', 'Tweet Id', 'Text', 'Username'])




