import logging
logging.basicConfig(level=logging.INFO)
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np
import nltk
from nltk import tokenize
from nltk.util import ngrams
import twipyUtil as util
import collections
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import spacy
import pandas as pd
import re
from spacy.tokens import Token
import vaderUtil as vaderUtil
import textblobUtil as textblobUtil
import polyglotUtil as polyglotUtil
import textoUtil as textoUtil
import time
import regex

start_time = time.time()

#!python -m spacy download pt
spacy_nlp_pt = spacy.load('pt')

#ferramentas = ["vader", "textblob", "polyglot", "polyglot_pt"]
ferramentas = ["vader", "textblob"]




#Ref: https://plotly.com/python/sunburst-charts/




def obterFrequencia(df, max=1000000):

    top_words = []
    list_of_words = []
    for t in df.texto_sem_stopwords:


        tokens = tokenize.word_tokenize(t, language='portuguese')
        '''
        for token in tokens:
            list_of_words.append(token.lower())
        '''

        for e in ngrams(tokens, 1):
            list_of_words.append(' '.join(e).strip())

    counter = collections.Counter(list_of_words)  # Conta a frequencia
    mais_comuns = counter.most_common(max)  # retorna uma lista com as mais frequentes
    top_words = [i for i in mais_comuns]


    # g_df = pd.DataFrame(data=top_words, columns=["Palavra", "Frequência"])
    # arquivoHtml = './resources/coletas_twipy/nuvens_de_palavras{}.html'.format(randomString())
    # print("arquivoHtml: " + arquivoHtml)
    # print(tabulate(g_df, headers='keys', tablefmt='grid'))
    # g_df.to_html(arquivoHtml)
    return top_words

def extractNounsAndVerbsAndAdjectves(df, idioma='portuguese'):
    #ref: https://pythonprogramming.net/sentiment-analysis-python-textblob-vader/

    text = nltk.word_tokenize(text, idioma)
    pos_tagged = nltk.pos_tag(text)

    nouns = filter(lambda x: (x[1] == 'NN') or (x[1] == 'VB') or (x[1] == 'JJ'), pos_tagged)
    nouns = [x[0] for x in nouns]
    return nouns

def remover_stopwords(text, idioma='portuguese'):
    text = text.replace(':', '')
    text = text.replace(' ', '')
    #text = text.replace('trade', 'commerce')
    #text = text.replace('opening', 'open')
    tokens = nltk.tokenize.word_tokenize(text)
    stopwordsPt = nltk.corpus.stopwords.words(idioma)
    filtered_sentence = [w for w in tokens if not w in stopwordsPt]
    return ' '.join(filtered_sentence)

def filtrarPalavrasPositivasENegativasEFrequencia(df):

    corpus = ""
    stop = nltk.corpus.stopwords.words("portuguese")

    df['texto_sem_stopwords'] = df['texto_limpo'].apply(lambda x: ' '.join([word for word in x.split() if word.lower() not in (stop)]))
    df['texto_sem_stopwords'] = df['texto_sem_stopwords'].apply(lambda x: textoUtil.lemma(x, "portuguese",
                                                                                          excluir=['SYM', 'NUM', 'PRON',
                                                                                                   'PROPN', 'PUNCT',
                                                                                                   'SPACE', 'DET',
                                                                                                   'CCONJ','VERB'],
                                                                                          lematizar=[]))

    #nounsAndVebs = extractNounsAndVerbsAndAdjectves(corpus)

    top_words = obterFrequencia(df)

    # corpus = ' '.join(top_words)

    # tokenized_sentence = nltk.word_tokenize(corpus)
    pos_word_list = []
    neu_word_list = []
    neg_word_list = []

    for i in range(len(top_words)):
        word = top_words[i][0]

        sent_poliPT_compound, sent_poliPT_categ, sent_poliPT_subcateg = polyglotUtil.polyglot_polarity_scores_categ_and_subcateg(word, polyglotUtil.IDIOMA_PT)

        if sent_poliPT_categ == 'POS':
            pos_word_list.append(top_words[i])
        elif sent_poliPT_categ == 'NEG':
            neg_word_list.append(top_words[i])
        else:
            neu_word_list.append(top_words[i])

    retorno = {'POS': pos_word_list, 'NEU': neu_word_list, 'NEG': neg_word_list}
    return retorno

def gravarCsvLimpo(ferramenta):

    print("gravarCsvLimpo - processando ferramenta: " + ferramenta);

    base_path = "C:/Users/junior/Google Drive/_Mestrado/SEAN/Dissertacao_Celso/resources/datasets/exp2/"
    records = base_path + ferramenta + "_exp2_word_cloud_verificando.csv"

    df = pd.read_csv(records)
    df.fillna('', inplace=True)
    df = df.astype(str)  # Converto todas as colunas para string

    # df = df[df['relacionamento']=='tweet']
    #df = df[df['flag'] == 'A']

    # print(df_antes.head())
    print(df.head())

    idioma = ""
    if ferramenta == "polyglot_pt":
        idioma = "portuguese"
    else:
        idioma = "english"

    #df['texto_sem_stopwords'] = df['texto'].apply(lambda x: x.lower().replace('genocida', 'assassino'))

    if idioma == "portuguese":
        df['texto_sem_stopwords'] = df['texto'].apply(lambda x: x.lower().replace('governo', '').replace('presidente', '').replace('bolsonaro', ''))
    elif idioma == "english":
        df['texto_sem_stopwords'] = df['texto'].apply(lambda x: x.lower().replace('government', '').replace('president', '').replace('bolsonaro', ''))
        df['texto_sem_stopwords'] = df['texto_sem_stopwords'].apply(
            lambda x: x.lower().replace('\'n', '').replace('\'s', '').replace('\'t', ''))


    df['texto_sem_stopwords'] = df['texto_sem_stopwords'].apply(lambda x: textoUtil.remover_stopwords(x, idioma))

    df['texto_sem_stopwords'] = df['texto_sem_stopwords'].apply(lambda x: textoUtil.lemma(x, idioma,
                                                                                          excluir=['SYM', 'NUM', 'PUNCT', 'SPACE',
                                                                                                   #'PRON'
                                                                                                   #'PROPN',
                                                                                                   #'DET',
                                                                                                   #'CCONJ',
                                                                                                   'X'
                                                                                                   ],
                                                                                          lematizar=[
                                                                                              #'NOUM'
                                                                                               ]))

    df['texto_sem_stopwords'] = df['texto_sem_stopwords'].apply(lambda x: textoUtil.removeEmoji(x, idioma))

    df.to_csv(base_path + ferramenta + "_exp2_word_cloud_limpo.csv", encoding='utf-8', index=False)

def getDf():
    print("filtrarPalavrasPositivasENegativasEFrequencia2 - processando ferramenta: " + ferramenta);

    base_path = "C:/Users/junior/Google Drive/_Mestrado/SEAN/Dissertacao_Celso/resources/datasets/exp2/"
    records = base_path + ferramenta + "_exp2_word_cloud_limpo.csv"

    df = pd.read_csv(records)
    df.fillna('', inplace=True)
    df = df.astype(str)  # Converto todas as colunas para string

    # df = df[df['relacionamento']=='tweet']
    df = df[df['flag'] == 'A']

    # print(df_antes.head())
    print(df.head())
    print(df.shape)

    return df

def filtrarPalavrasPositivasENegativasEFrequencia2(ferramenta, grupo):

    print("filtrarPalavrasPositivasENegativasEFrequencia2 - processando ferramenta: " + ferramenta);

    base_path = "C:/Users/junior/Google Drive/_Mestrado/SEAN/Dissertacao_Celso/resources/datasets/exp2/"
    records = base_path + ferramenta + "_exp2_word_cloud_limpo.csv"

    df = pd.read_csv(records)
    df.fillna('', inplace=True)
    df = df.astype(str)  # Converto todas as colunas para string

    # df = df[df['relacionamento']=='tweet']
    df = df[df['flag'] == grupo]

    # print(df_antes.head())
    print(df.head())
    print(df.shape)

    pos_word_list = []
    neu_word_list = []
    neg_word_list = []

    idioma = ""
    if ferramenta == "polyglot_pt":
        idioma = "portuguese"
    else:
        idioma = "english"

    print("--- %s Iniciando conjuntos ---" % (time.time() - start_time))
    for index, t in df.iterrows():

        t.texto_sem_stopwords = regex.sub(r'[^\w]', ' ', t.texto_sem_stopwords)
        tokens = tokenize.word_tokenize(t.texto_sem_stopwords, language='portuguese')
        for e in ngrams(tokens, 1):
            termo = ' '.join(e).strip();

            compound, categ, subcateg = "", "", ""

            if ferramenta == "vader":
                compound, categ, subcateg = vaderUtil.vader_polarity_scores_categ_and_subcateg(termo)
            elif ferramenta == "textblob":
                compound, categ, subcateg, subjetividade = textblobUtil.textblob_polarity_scores_categ_and_subcateg(termo)
            elif ferramenta == "polyglot" or ferramenta == "polyglot_pt":
                compound, categ, subcateg = polyglotUtil.polyglot_polarity_scores_categ_and_subcateg(termo, idioma)


            if t['categ'] =='POS' and categ == 'POS':
                pos_word_list.append(termo)
            elif t['categ'] =='NEG' and categ == 'NEG':
                neg_word_list.append(termo)
            elif t['categ'] =='NEU' and categ == 'NEU':
                neu_word_list.append(termo)


    max = 1000000
    counter_pos = collections.Counter(pos_word_list)  # Conta a frequencia
    mais_comuns_pos = counter_pos.most_common(max)  # retorna uma lista com as mais frequentes
    top_words_pos = [i for i in mais_comuns_pos]

    counter_neu = collections.Counter(neu_word_list)  # Conta a frequencia
    mais_comuns_neu = counter_neu.most_common(max)  # retorna uma lista com as mais frequentes
    top_words_neu = [i for i in mais_comuns_neu]

    counter_neg = collections.Counter(neg_word_list)  # Conta a frequencia
    mais_comuns_neg = counter_neg.most_common(max)  # retorna uma lista com as mais frequentes
    top_words_neg = [i for i in mais_comuns_neg]

    retorno = {'POS': top_words_pos, 'NEU': top_words_neu, 'NEG': top_words_neg}

    for i in retorno:
        g_df = pd.DataFrame(data=retorno[i], columns=["Palavra", "Frequência"])
        arquivoHtml = base_path + "{}_{}_{}_wordcloud_verificando.html".format(ferramenta, i, grupo)
        g_df.to_html(arquivoHtml)

    return retorno

def plotar_word_clod_from_freq(dict_freq, ferramenta, categ, grupo, max_words=50, mask_image=None):
    mask = None
    if not (mask_image is None):
        mask = np.array(Image.open(os.path.join(mask_image)))

    # max_words = 50
    wc = WordCloud(background_color="white",
                   #stopwords=stopwordsPt,
                   max_words=max_words, mask=mask, contour_width=1,
                   contour_color='black')
    #wc.generate(texto)

    wc.generate_from_frequencies(dict_freq)
    base_path = "C:/Users/junior/Google Drive/_Mestrado/SEAN/Dissertacao_Celso/resources/datasets/exp2/"

    wc.to_file(base_path + ferramenta + "_" + categ + "_" + grupo + "_wordcloud_verificando.png")

    # show
    #plt.imshow(wc, interpolation='bilinear')
    #plt.axis("off")
    #plt.show()

def plotar_word_clod_from_text(texto, max_words=50, mask_image=None):
    mask = None
    if not (mask_image is None):
        mask = np.array(Image.open(os.path.join(mask_image)))

    # max_words = 50
    wc = WordCloud(background_color="white",
                   #stopwords=stopwordsPt,
                   max_words=max_words, mask=mask, contour_width=1,
                   contour_color='black')
    wc.generate(texto)

    # show
    plt.imshow(wc, interpolation='bilinear')
    plt.axis("off")
    plt.show()

print("--- %s Inicio ---" % (time.time() - start_time))


#for ferramenta in ferramentas:
#    gravarCsvLimpo(ferramenta);



#df = getDf();
#plotar_word_clod_from_text(' '.join(df['texto']))

#grupos = ['A','D']
grupos = ['A']
for ferramenta in ferramentas:
    for grupo in grupos:
        print("ferramenta:{} grupo:{}".format(ferramenta,grupo))
        lista_freq = filtrarPalavrasPositivasENegativasEFrequencia2(ferramenta, grupo);

        lista_freq_pos = dict(lista_freq["POS"])
        lista_freq_neu = dict(lista_freq["NEU"])
        lista_freq_neg = dict(lista_freq["NEG"])

        print("--- %s plotar wc ---" % (time.time() - start_time))
        plotar_word_clod_from_freq(lista_freq_pos, ferramenta,  "POS", grupo)
        plotar_word_clod_from_freq(lista_freq_neu, ferramenta, "NEU", grupo)
        plotar_word_clod_from_freq(lista_freq_neg, ferramenta, "NEG", grupo)

        print("--- %s seconds ---" % (time.time() - start_time))
