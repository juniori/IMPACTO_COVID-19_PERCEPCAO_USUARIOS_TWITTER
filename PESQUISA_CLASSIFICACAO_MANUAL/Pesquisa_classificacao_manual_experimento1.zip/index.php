<?php 
session_start(); 


if (!isset($_SESSION['qtd'])) {
  $_SESSION["qtd"] = 0;
  $_SESSION["qtd_limite"] = 50;
}

if ($_SESSION["qtd"] == $_SESSION["qtd_limite"]){
	header('Location: obrigado.php');	 
	die();
}
	
	
?>

<?php header("Content-type: text/html; charset=utf-8"); ?>

<?php

#https://developer.twitter.com/en/docs/twitter-for-websites/embedded-tweets/guides/embedded-tweet-parameter-reference


include 'services.php'; 

$rows = buscarListaSorteada();  
	
?>

<!DOCTYPE html>
<html>
<head>
<title>Pesquisa Qualitativa - Tweets</title>
<meta charset="UTF-8">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script
  src="https://code.jquery.com/jquery-3.6.0.min.js"
  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
  crossorigin="anonymous"></script> 

<style>

body{
	background-color:#f1f1f1;
}

.container{
	display:none;
}

#overlay {
  position: fixed; /* Sit on top of the page content */
  display: none; /* Hidden by default */
  width: 100%; /* Full width (cover the whole page) */
  height: 100%; /* Full height (cover the whole page) */
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0,0,0,0.5); /* Black background with opacity */
  z-index: 2; /* Specify a stack order in case you're using a different order for other elements */
  cursor: pointer; /* Add a pointer on hover */
}
#text_overlay{
  position: absolute;
  top: 50%;
  left: 50%;
  font-size: 15px;
  color: white;
  transform: translate(-50%,-50%);
  -ms-transform: translate(-50%,-50%);
}

#divForm{
	display:none
}

p.texto_modal {
  text-align: justify;
  text-justify: inter-word;
}

</style>


<script>
window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));

twttr.ready(
  function (twttr) {
        
		twttr.widgets.createTweet(
		  '<?php echo $rows[0]['id']?>',
		  document.getElementById('container'), 
		  {
			//theme: 'dark',
			conversation:'none',
			cards:'hidden',
			dnt:'true'
		  }
		);
		
		twttr.events.bind(
		  'loaded',
		  function (event) {
			  //alert('loaded')
			$(".container").show("slow")
			
			setTimeout(function(){
				if (!$("#container").html()){
					window.location.reload()
				}
			}, 4000)
		  }
		);
		
		twttr.events.bind(
		  'rendered',
		  function (event) { 
		    console.log('rendered') 
			$(".progress").hide()
			$("#divForm").show("slow")
			
			
			
		  }
		);


	
  }
);

$( document ).ready(function() {
	
		$('#form1').on('submit', function(e){
			if(!$("input[type=radio]:checked").val()){
				e.preventDefault();
				alert("Selecione uma opção de resposta")
			}else{
				$(".container").hide()
				document.getElementById("overlay").style.display = "block";	
				
			}
			
	
		});
		
		
		
});

</script>

</head>
<body>

 <!-- Modal Trigger -->
 <a class="waves-effect waves-light btn modal-trigger" href="#modal1" id="bt_ajuda">Ajuda
 <i class="material-icons right">help_outline</i>
 </a>
  
<div id="overlay">
<div id="text_overlay">
	<?php if ($_SESSION["qtd"]+1 != $_SESSION["qtd_limite"]){ ?>
		<a class="btn-floating btn-large pulse"><i class="material-icons">schedule</i></a>&nbsp;Carregando...(<?php echo $_SESSION["qtd"]+2 ?>/<?php echo $_SESSION["qtd_limite"]?>)
	<?php } else{ ?>
		<a class="btn-floating btn-large pulse"><i class="material-icons">schedule</i></a>&nbsp;Obrigado!    	
	<?php } ?>
</div> 
</div>

<div class="container">

	<div class="progress">
	  <div class="indeterminate"></div>
	</div>

	<div class="row">
		<div class="col s12 m6">
			<span class="badge"><?php echo $_SESSION["qtd"]+1?>/<?php echo $_SESSION["qtd_limite"]?></span>			  
		</div>
	</div>	
			  

	<div class="row">
		<div class="col s12 m6">
			<div id="container"></div>
		</div>
	</div>	
	
	<div id="divForm">
	<div class="row black-text  " >
		<div class="col s12 m6">
			<div><strong>Como você classificaria a mensagem deste tweet?</strong></div> 
				<div>A mensagem é: </div>		
		</div>
	</div>
	<div class="row black-text  " >
		<div class="col s12 m6 z-depth-1 white">	
		
			<form id="form1" action="services.php" method="get" >
			
				<input type="hidden" name="session_id" value="<?php echo session_id();?>">
				<input type="hidden" name="id" value="<?php echo $rows[0]['id']?>">
				<input type="hidden" name="termo" value="<?php echo $rows[0]['termo']?>">
				<input type="hidden" name="acao" value="salvar">

	
                 <br>
				<fieldset> 
				<div>
				 <label for="Neutra"> <input type="radio" id="Neutra" name="subcateg_manual" value="Neutra"><span class="black-text">Neutra</span></label>
				</div>
				</fieldset> 			
				<fieldset class="blue-text"> 
				<legend><strong>Positiva</strong></legend>
				<div >
				 <label for="Positivo_Fraco"> <input type="radio" id="Positivo_Fraco" name="subcateg_manual" value="Positivo Fraco"><span class="blue-text">Fraco</span></label>
				 <label for="Positivo_Medio"> <input type="radio" id="Positivo_Medio" name="subcateg_manual" value="Positivo Médio"><span class="blue-text">Médio</span></label>
				 <label for="Positivo_Forte"> <input type="radio" id="Positivo_Forte" name="subcateg_manual" value="Positivo Forte"><span class="blue-text">Forte</span></label>
				</div>
				</fieldset> 

				<fieldset class="red-text"> 
				<legend><strong>Negativa</strong></legend>
				<div>
				 <label for="Negativo_Fraco"> <input type="radio" id="Negativo_Fraco" name="subcateg_manual" value="Negativo Fraco"><span class="red-text">Fraco</span></label>
				 <label for="Negativo_Medio"> <input type="radio" id="Negativo_Medio" name="subcateg_manual" value="Negativo Médio"><span class="red-text">Médio</span></label>
				 <label for="Negativo_Forte"> <input type="radio" id="Negativo_Forte" name="subcateg_manual" value="Negativo Forte"><span class="red-text">Forte</span></label>
				</div>
				</fieldset> 	
			
			
				<div class="row black-text" > 
					<div class="col s12 m6">&nbsp;
					</div>
				</div>				

				<div class="row black-text" >
					<div class="col s12 center-align">			
						  <button class="btn waves-effect waves-light center" type="submit" id="bt_submit">Próximo
							<i class="material-icons right">send</i>
						  </button>			
					</div>
				</div> 

	
			</form>				
			</div>
	</div>
	</div>


			

			
		
		
		
</div>	


  
 <!-- Modal Structure -->
  <div id="modal1" class="modal modal-fixed-footer">
    <div class="modal-content">
	 <?php 
	if ($_SESSION["qtd"] == 0){
	 ?>
      <h4>Olá! </h4>
      <p class="texto_modal">Você foi convidada(o) para participar de uma pesquisa com objetivo de analisar os sentimentos de <?php echo $_SESSION["qtd_limite"]?> tweets pré-selecionados.</p>	  
	  
	 <?php 
	}
	 ?>
 
      <h4>Como Avaliar os Tweets?</h4>
      <p class="texto_modal">Avalie o tweet de acordo com o seu sentimento com relação a frase apresentada. 
	  Nessa avaliação você deve apenas considerar se ela é uma frase positiva (fraca e forte), 
	  negativa (fraca e forte) ou neutra independentemente de sua orientação ideológica, política, 
	  partidária ou religiosa. 
	  Por exemplo, em uma frase "Eu odeio esse mundo cruel e injusto!" 
	  deverá ser avaliada como fortemente negativa, pois possui palavras "odeio", "cruel" e "injusto". 
	  Da mesma forma, a frase "Eu estou viajando." deve ser entendida como neutra ou 
	  fracamente positiva por causa da palavra "viajando" que pode ser entendida como uma palavra positiva.</p>
	  <p class="texto_modal">	  
		Cuidado! Não se trata de concordar ou discordar da frase... 
		é só para avaliar a frase expressa sentimentos positivos, negativos ou neutro, por exemplo: 
		a frase "Eu odeio quem bate em mulheres.", por mais que você concorde com a frase, é uma frase 
		que deve ser classificada como negativa porque expressa sentimentos negativos. É nesse sentido que 
		deve ser avaliado. Não é o seu sentimento, é o sentimento da frase.	  
	  </p>
	  
	  <p class="texto_modal">	  
		<b>Qualquer dúvida é só entrar em contato com Celso Pacheco Jr ou Marcelo Loutfi.</b>
	  </p>
	  
	  
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">
	 <?php 
	if ($_SESSION["qtd"] == 0){
	 ?>	  
	  Iniciar
	 <?php 
	}else{
	 ?>	  
	 Fechar
	 <?php 
	}
	 ?>	 
	  </a>
    </div>
  </div>  

<script>
 M.AutoInit();
 
  
 <?php 
if ($_SESSION["qtd"] == 0){
 ?>
	  var instance = M.Modal.getInstance($('.modal')[0]);
	  instance.open();
 
 <?php 
}
 ?>
 
 </script>
</body>

</html>


 