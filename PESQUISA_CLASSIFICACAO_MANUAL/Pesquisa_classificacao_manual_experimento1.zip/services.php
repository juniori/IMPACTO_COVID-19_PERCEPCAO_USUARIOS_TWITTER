<?php
session_start(); 
date_default_timezone_set('America/Sao_Paulo');

include 'environment.php';
include 'lib.php';

$acao = isset($_GET['acao'])?$_GET['acao']:'';

header('Access-Control-Allow-Origin:*');    

 

if ($acao == 'salvar'){
	salvar();
}
 
if ($acao == 'reset'){
	print("reset desabilitado!");
	die();
	#resetar();
}
  

function salvar(){

	global $conn;

	$id = $_GET['id'];
	$termo = $_GET['termo'];
	$session_id = $_GET['session_id'];
	$subcateg_manual = $_GET['subcateg_manual'];
	$dataLocal = date('Y/m/d H:i:s', time());	
	
	openConnection(); 

	$sql = "update dataset_tweets_bert_timeline_1_correcao set sent_vader_subcateg_manual=?, avaliador=?, updated_at=?  where id=? and termo=?"; 	 	
	$stmt = $conn->prepare($sql);
	$stmt->bind_param("sssss", $subcateg_manual, $session_id, $dataLocal, $id, $termo );
	if ($stmt->execute() === FALSE) {
		throw new Exception("Erro ao salvar alteração: " . $sql . "<br>" . $conn->error);
	}
	
    $stmt->close();		
	closeConnection(); 
	
	$_SESSION["qtd"] = ($_SESSION["qtd"] + 1);
	
	if ($_SESSION["qtd"] == $_SESSION["qtd_limite"]){
		header('Location: obrigado.php');	 
		die();
	}else{
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		die();
	}
	
	
	
}

function buscarListaSorteada(){
	
	global $conn;
	openConnection();
	
	$rows=array();

	$sql = "SELECT id, termo,  texto_original from dataset_tweets_bert_timeline_1_correcao where sent_vader_subcateg_manual is null  order BY RAND() limit 1 ";


	foreach ( $conn->query($sql) as $row ) {
		$rows[]= $row;
	}

	$conn->close();		
	
	if (count($rows) == 0){
		print("Pesquisa concluída. Não existem mais tweets a serem classificados!");
		exit();
	}
	
	return $rows; 
	
}



function buscarTodas(){ 
	
	global $conn;
	openConnection();
	
	$rows=array(); 

	$sql = "SELECT id, termo, avaliador, updated_at, flag, texto_original, sent_vader_subcateg, sent_vader_subcateg_manual from dataset_tweets_bert_timeline_1_correcao where sent_vader_subcateg_manual is not null order by updated_at";


	foreach ( $conn->query($sql) as $row ) {
		$rows[]= $row;
	}
	

	$conn->close();		
	
	return $rows; 
	
}



function resetar(){

	global $conn;

	$id = $_GET['id'];
	$termo = $_GET['termo'];
	
	openConnection(); 

	$sql = "update dataset_tweets_bert_timeline_1_correcao set sent_vader_subcateg_manual=null, avaliador=null, updated_at=null "; 	 	
	$stmt = $conn->prepare($sql);
	#$stmt->bind_param("sss", $subcateg_manual, $id, $termo );
	if ($stmt->execute() === FALSE) {
		throw new Exception("Erro ao salvar alteração: " . $sql . "<br>" . $conn->error);
	}
	
    $stmt->close();		
	closeConnection(); 
	
	header('Location: relatorio.php');	 
	die();
	
	
	
}



?>
