<?php

if ($isProducao){
	$servername = "localhost";
	$username = "celsojr_pesquisa";
	$password = "";
	$dbname = "celsojr_pesquisa";
	$conn = "";
}
	
	

	
function openConnection(){
	
    global $servername;
	global $username;
	global $password;
	global $dbname;  
	global $conn;
	

	$conn = new mysqli($servername, $username, $password, $dbname);
	
	mysqli_set_charset($conn,"utf8");
	
	
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 	
}


function closeConnection(){ 

	global $conn;
	
	try{
		$conn->close();
		} catch (Exception $e) { 
			
		}
	

	
}



	
?>