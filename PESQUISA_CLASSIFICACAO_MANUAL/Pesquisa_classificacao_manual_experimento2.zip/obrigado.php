<?php
include 'services.php'; 

$rows = dadosGrafico();  

?>

<?php
header("Content-type: text/html; charset=utf-8"); 
?>


<!DOCTYPE html>
<html>
<head>
<title>Pesquisa Qualitativa - Tweets</title>
<meta charset="UTF-8">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<script src="js/jquery-3.6.0.min.js"></script>

<script src="https://cdn.anychart.com/releases/8.11.0/js/anychart-core.min.js"></script>
<script src="https://cdn.anychart.com/releases/8.11.0/js/anychart-sunburst.min.js"></script>

<style>


body{
	background-color:#f1f1f1;
}

.container{
	display:none;
}

#overlay {
  position: fixed; /* Sit on top of the page content */
  display: none; /* Hidden by default */
  width: 100%; /* Full width (cover the whole page) */
  height: 100%; /* Full height (cover the whole page) */
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0,0,0,0.5); /* Black background with opacity */
  z-index: 2; /* Specify a stack order in case you're using a different order for other elements */
  cursor: pointer; /* Add a pointer on hover */
}
#text_overlay{
  position: absolute;
  top: 50%;
  left: 50%;
  font-size: 15px;
  color: white;
  transform: translate(-50%,-50%);
  -ms-transform: translate(-50%,-50%);
}

#form1{
	display:none
}

.imgpb {
  filter: grayscale(100%);
}

</style>

<?php
$tweets = 0;

$positivoFr = 0;
$positivoMe = 0;
$positivoFo = 0;

$neutros = 0;

$negativoFr = 0;
$negativoMe = 0;
$negativoFo = 0;



	foreach ($rows as &$row) {
	
		switch ($row['categ']) {
			case "Positivo Fraco":
				$positivoFr = $row['qtd'];
				break;
			case "Positivo Médio":
				$positivoMe = $row['qtd'];
				break;
			case "Positivo Forte":
				$positivoFo = $row['qtd'];
				break;
			case "Negativo Fraco":
				$negativoFr = $row['qtd'];
				break;
			case "Negativo Médio":
				$negativoMe = $row['qtd'];
				break;
			case "Negativo Forte":
				$negativoFo = $row['qtd'];
				break;		
			case "Neutro":
				$neutros = $row['qtd'];
				break;				
		}		

	}

$positivos = $positivoFr + $positivoMe + $positivoFo;
$negativos = $negativoFr + $negativoMe + $negativoFo;

$tweets = 	$positivos + $negativos + $neutros;
?>
    

<script>
anychart.onDocumentReady(function () {

    // create data
    var data = [
      {name: "<span style='color:#000'>Tweets<br>Avaliados<br>"+<?php echo $tweets ?>+"</span>", normal:{fill: "white"} , value:"<span style='color:#000'>" + <?php echo $tweets ?> + "</span>", children: [
        {name: "Positivos", normal:{fill:"DarkOliveGreen"}, value: <?php echo $positivos  ?>, children: [
          {name: "Fraco", value: <?php echo $positivoFr ?>}, {name: "Médio", value: <?php echo $positivoMe ?>}, {name: "Forte", value: <?php echo $positivoFo ?>}
        ]},
        {name: "Negativos", normal:{fill:"Chocolate"}, value: <?php echo $negativos  ?>, children: [
          {name: "Fraco", value: <?php echo $negativoFr ?>}, {name: "Médio", value: <?php echo $negativoMe ?>}, {name: "Forte", value: <?php echo $negativoFo ?>}
        ]},
        {name: "Neutros", normal:{fill:"CornflowerBlue"}, value: <?php echo $neutros ?>}         
      ]}
    ];

    // create a chart and set the data
    var chart = anychart.sunburst(data, "as-tree");

    // set the calculation mode
    chart.calculationMode("parent-dependent");

    // set the chart title
    chart.title().useHtml(true);
    chart.title("Resultado Parcial")
	chart.title().fontColor("white");

    // set the container id
    chart.container("container");
	
	var labels = chart.labels();
	labels.fontSize(14);
	labels.useHtml(true);	
	
	// configure labels
	chart.labels().format("{%name}<br>{%value}");

	// configure labels of leaves
	chart.leaves().labels().format("{%name}<br>{%value}");
	
	chart.background().fill("none");
	
	chart.fill(function () {
	  if (this.parent)
		return anychart.color.lighten(this.parentColor, 0.3);
	  return this.mainColor;
	});

	
    // initiate drawing the chart
    chart.draw();
});

$( document ).ready(function() {
	$("#btn_salvar_email").on('click', function(e){
		e.preventDefault();
		
			let email = $("#email_inline")
			if (!email.val() || !email.val().includes("@")){
				M.toast({html:"Informe um e-mail válido!" ,classes:"red" ,displayLength:1000})
				email.focus();
				email.addClass('active');
				
			}else{
				salvarEmail(email.val());
				
			}
		
		
	})
	
	
});


function salvarEmail(email){
	
var jqxhr = $.get( "https://pesquisa.celsojr.com.br?acao=salvarEmail&email="+email, function() {
	
	M.toast({html:"E-mail salvo com sucesso!" ,classes:"green" ,displayLength:1000, completeCallback:function(){
					
					$("#email_container").hide( "slow") 
					
				
				}})
})
.fail(function() {
	M.toast({html:"Erro ao salvar e-mail",classes:"red" ,displayLength:1000})
});

	
}

		
		

</script>


</head>
<body>


 <?php 
 
$envio_email = '
		  <div class="row valign-wrapper">
            <div class="col s12">
				
				<div class="col s12 m8 offset-m2 l6 offset-l3 " id="email_container">
				<div class="card-panel z-depth-1">
				 <div class="row">
						<div class="col s9 m6">
						  Deseja receber o resultado final em seu e-mail?
						  <div class="input-field inline">
							<input id="email_inline" type="email" class="validate">
							<label for="email_inline">Informe seu e-mail</label>
						  </div>
						</div>
						<div class="col s3 m6 input-field inline">
							
							<button  class="waves-effect waves-light btn" id="btn_salvar_email">Enviar</button> 
						</div>		
				</div>
				</div>
				</div>	
				
            </div>
          </div>	
';

$n1_cor_fundo = "light-green";
$n1_img = "<img src=\"nivel1.png\" alt=\"\" class=\"circle responsive-img\">";
$n1_cor_texto = "white-text";
$n1_msg = "
				<b>Muito obrigado por participar!</b>
				<br>
				<br>
				Como reconhecimento por sua ajuda, lhe conferimos o título de <b>Participante Medalhista Honorário</b>!
				<br>
				Gostaria de continuar respondendo e obter o próximo nível?
				<br>
				<br>
				<a class=\"waves-effect waves-light btn\" href=\"https://pesquisa.celsojr.com.br/\"><i class=\"material-icons left\">send</i>Avançar para o próximo nível</a>
				
				
";
$n1_chart = "<div id='container'  style='width: 350px; height: 400px;'></div>";
$n1_envio_email = $envio_email;



$n2_cor_fundo = "grey lighten-5";
$n2_img = "<img src=\"nivel2.png\" alt=\"\" class=\"circle responsive-img imgpb\">";
$n2_cor_texto = "black-text";
$n2_msg = "Medalha de Ultra Participante Legal!";
$n2_chart = "";
$n2_envio_email = "";


$n3_cor_fundo = "grey lighten-5";
$n3_img = "<img src=\"nivel3.png\" alt=\"\" class=\"circle responsive-img imgpb\">";
$n3_cor_texto = "black-text";
$n3_msg = "Troféu Participante Gente Boa Sensacional do Ano!";
$n3_chart = "";
$n3_envio_email = "";


$n4_cor_fundo = "grey lighten-5";
$n4_img = "<img src=\"nivel4.png\" alt=\"\" class=\"circle responsive-img imgpb\">";
$n4_cor_texto = "black-text";
$n4_msg = "Mestre Jedi da Participação em Pesquisa Acadêmica!";
$n4_chart = "";
$n4_envio_email = "";



if ($_COOKIE['nivel'] > 1){
$n1_cor_fundo = "light-green";
$n1_img = "<img src=\"nivel1.png\" alt=\"\" class=\"circle responsive-img\">";
$n1_cor_texto = "white-text";
$n1_msg = "<b>Participante Medalhista Honorário</b>!";
$n1_chart = "";
$n1_envio_email = "";
	
$n2_cor_fundo = "light-green";
$n2_img = "<img src=\"nivel2.png\" alt=\"\" class=\"circle responsive-img\">";
$n2_cor_texto = "white-text";
$n2_msg = "
				<b>Muito obrigado por participar mais uma vez!</b>
				<br>
				<br>
				Como reconhecimento por sua ajuda, lhe conferimos a <b>Medalha de Ultra Participante Legal</b>!
				<br>
				Gostaria de continuar respondendo e obter o próximo nível?
				<br>
				<br>
				<a class=\"waves-effect waves-light btn\" href=\"https://pesquisa.celsojr.com.br/\"><i class=\"material-icons left\">send</i>Avançar para o próximo nível</a>
				
";
$n2_chart = "<div id='container'  style='width: 350px; height: 400px;'></div>";
$n2_envio_email = $envio_email;	
}

if ($_COOKIE['nivel'] > 2){
$n2_cor_fundo = "light-green";
$n2_img = "<img src=\"nivel2.png\" alt=\"\" class=\"circle responsive-img\">";
$n2_cor_texto = "white-text";
$n2_msg = "<b>Medalha de Ultra Participante Legal</b>!";
$n2_chart = "";
$n2_envio_email = "";
	
$n3_cor_fundo = "light-green";
$n3_img = "<img src=\"nivel3.png\" alt=\"\" class=\"circle responsive-img\">";
$n3_cor_texto = "white-text";
$n3_msg = "
				<b>Muito obrigado por participar mais uma vez!</b>
				<br>
				<br>
				Como reconhecimento por sua ajuda, lhe conferimos o <b>Troféu Participante Gente Boa Sensacional do Ano</b>!
				<br>
				Gostaria de continuar respondendo e obter o próximo nível?
				<br>
				<br>
				<a class=\"waves-effect waves-light btn\" href=\"https://pesquisa.celsojr.com.br/\"><i class=\"material-icons left\">send</i>Avançar para o próximo nível</a>
				
";
$n3_chart = "<div id='container'  style='width: 350px; height: 400px;'></div>";	
$n3_envio_email = $envio_email;	
}

if ($_COOKIE['nivel'] > 3){
$n3_cor_fundo = "light-green";
$n3_img = "<img src=\"nivel3.png\" alt=\"\" class=\"circle responsive-img\">";
$n3_cor_texto = "white-text";
$n3_msg = "<b>Troféu Participante Gente Boa Sensacional do Ano</b>!";
$n3_chart = "";
$n3_envio_email = "";
	
$n4_cor_fundo = "light-green";
$n4_img = "<img src=\"nivel4.png\" alt=\"\" class=\"circle responsive-img\">";
$n4_cor_texto = "white-text";
$n4_msg = "
				<b>Você completou a pesquisa e alcançou o último nível! </b>
				<br>
				<br>
				Como reconhecimento por sua ajuda, lhe conferimos o título de <b>Mestre Jedi da Participação em Pesquisa Acadêmica</b>!
				<br>
				<br> 
				<b>Muito obrigado por colaborar! </b>
				
				
";
$n4_chart = "<div id='container'  style='width: 350px; height: 400px;'></div>";
$n4_envio_email = $envio_email;		
}

 ?>
 
  

		<div class="col s12 m8 offset-m2 l6 offset-l3 ">
        <div class="card-panel <?php echo $n1_cor_fundo;?> z-depth-1">
          <div class="row valign-wrapper">
            <div class="col s2">
              <?php echo $n1_img;?>
            </div>
            <div class="col s10">
              <span class="<?php echo $n1_cor_texto;?>">
                 <?php echo $n1_msg;?>
              </span>
            </div>
          </div>
          <div class="row valign-wrapper">
            <div class="col s12">
				<?php echo $n1_chart;?>
            </div>
          </div>		
          
		  <?php echo $n1_envio_email?>
		  
        </div>
      </div>
	  

	  
	  
		<div class="col s12 m8 offset-m2 l6 offset-l3 ">
		<div class="card-panel <?php echo $n2_cor_fundo;?> z-depth-1">
		  <div class="row valign-wrapper">
			<div class="col s2">
			  <?php echo $n2_img;?>
			</div>
			<div class="col s10">
			  <span class="<?php echo $n2_cor_texto;?>">
				 <?php echo $n2_msg;?>
			  </span>
			</div>
		  </div>
          <div class="row valign-wrapper">
            <div class="col s12">
				<?php echo $n2_chart;?>
            </div>
          </div>

			<?php echo $n2_envio_email?>
		  
		</div>
	  </div>

	  
		<div class="col s12 m8 offset-m2 l6 offset-l3 ">
		<div class="card-panel <?php echo $n3_cor_fundo;?> z-depth-1">
		  <div class="row valign-wrapper">
			<div class="col s2">
			  <?php echo $n3_img;?>
			</div>
			<div class="col s10">
			  <span class="<?php echo $n3_cor_texto;?>">
				 <?php echo $n3_msg;?>
			  </span>
			</div>
		  </div>
          <div class="row valign-wrapper">
            <div class="col s12">
				<?php echo $n3_chart;?>
            </div>
          </div>	

		  <?php echo $n3_envio_email?>		  
		  
		</div>
	  </div>

		<div class="col s12 m8 offset-m2 l6 offset-l3 ">
		<div class="card-panel <?php echo $n4_cor_fundo;?> z-depth-1">
		  <div class="row valign-wrapper">
			<div class="col s2">
			  <?php echo $n4_img;?>
			</div>
			<div class="col s10">
			  <span class="<?php echo $n4_cor_texto;?>">
				 <?php echo $n4_msg;?>
			  </span>
			</div>
		  </div>
          <div class="row valign-wrapper">
            <div class="col s12">
				<?php echo $n4_chart;?>
            </div>
          </div>
		
		<?php echo $n4_envio_email?>			  
		
		</div>
	  </div>	  


<script>
 M.AutoInit();
 </script>
</body>

</html>


 