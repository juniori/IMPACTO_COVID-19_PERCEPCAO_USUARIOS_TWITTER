<?php header("Content-type: text/html; charset=utf-8"); ?>

<?php

include 'services.php'; 

$rows = buscarTodas();  
	
?>

<!DOCTYPE html>
<html>
<head>
<title>Pesquisa Qualitativa - Tweets</title>
<meta charset="UTF-8">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

<script src="js/materialize.min.js"></script>
<script src="js/jquery-3.6.0.min.js"></script>

<style>

body{
	background-color:#fff;
}



#overlay {
  position: fixed; /* Sit on top of the page content */
  display: none; /* Hidden by default */
  width: 100%; /* Full width (cover the whole page) */
  height: 100%; /* Full height (cover the whole page) */
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0,0,0,0.5); /* Black background with opacity */
  z-index: 2; /* Specify a stack order in case you're using a different order for other elements */
  cursor: pointer; /* Add a pointer on hover */
}
#text_overlay{
  position: absolute;
  top: 50%;
  left: 50%;
  font-size: 15px;
  color: white;
  transform: translate(-50%,-50%);
  -ms-transform: translate(-50%,-50%);
}

#form1{
	display:none
}

</style>



</head>
<body>


<div id="overlay">
<div id="text_overlay">
	<a class="btn-floating btn-large pulse"><i class="material-icons">schedule</i></a>&nbsp;Aguarde...
</div> 
</div>

<div class="container">


<div class="row">
	<div class="col s12">
		<span class="badge"><?php echo count($rows); ?> Tweets</span>			  
	</div>
</div>	
			  

 <table class="striped z-depth-1"> 
        <thead>
          <tr>
              <th>Id</th>
			  <th>Antes/Depois</th>
              <th>Conteúdo</th>
              <th>Classif. Auto</th>
			  <th>Classif. Manual</th>
			  <th>Avaliador</th>
			  <th>Data</th>
          </tr>
        </thead>

        <tbody>
		<?php
		foreach ($rows as $v){ 
		?>			
          <tr>
            <td><?php echo $v["id"]?></td>
			<td class="center-align"><?php echo $v["flag"]?></td>
            <td><?php echo $v["texto_original"]?></td>
            <td><?php echo $v["sent_vader_subcateg"]?></td>
			<td><?php echo $v["sent_vader_subcateg_manual"]?></td>
			<td><?php echo $v["avaliador"]?></td>
			<td><?php echo $v["updated_at"]?></td>
			
          </tr>
		<?php
		}
		?>			  
        </tbody>
      </table>			  


</div>

<script>
 M.AutoInit();
 </script>
</body>

</html>


 