<?php
session_start(); 
date_default_timezone_set('America/Sao_Paulo'); 

include 'environment.php';
include 'lib.php';

$acao = isset($_GET['acao'])?$_GET['acao']:'';

//header('Access-Control-Allow-Origin:*');     

 


		
if ($acao == 'salvar'){
	// pesquisa encerrada
	print("Nada foi salvo. A pesquisa foi encerrada.");
	// ----------------------------------

	// salvar();
}

if ($acao == 'marcar_tweet_inexistente'){
	marcar_tweet_inexistente();  
}
 
if ($acao == 'reset'){
    #print("reset desabilitado!");
	#die();
	#resetar();
}


if ($acao == 'salvarEmail'){
	print("Nada foi salvo. A pesquisa foi encerrada.");
	//salvarEmail();
}

  

function salvar(){

	global $conn;

	$id = $_GET['id'];
	$session_id = $_GET['session_id'];
	$subcateg_manual = $_GET['subcateg_manual'];
	$dataLocal = date('Y/m/d H:i:s', time());	
	
	openConnection(); 

	$sql = "update dataset_tweets_base_2021_timeline_30dias_gov_origens_tweets_m set sent_manual_subcateg=?, avaliador=?, updated_at=?  where id=?"; 	 	
	$stmt = $conn->prepare($sql);
	$stmt->bind_param("ssss", $subcateg_manual, $session_id, $dataLocal, $id);
	if ($stmt->execute() === FALSE) {
		throw new Exception("Erro ao salvar alteração: " . $sql . "<br>" . $conn->error);
	}
	
    $stmt->close();		
	closeConnection(); 
	
	$_SESSION["qtd"] = ($_SESSION["qtd"] + 1); 
	setcookie("qtd",$_SESSION["qtd"],time() + (10 * 365 * 24 * 60 * 60));
	
	$nivel = $_COOKIE['nivel'];
	
	if ($_SESSION["qtd"] == $_SESSION["qtd_limite"] * ($nivel +1) ){
		
		$nivel = $_COOKIE['nivel'] + 1; 
		setcookie("nivel",$nivel,time() + (10 * 365 * 24 * 60 * 60));
			
		
		header('Location: obrigado.php',true, 302);	 
		die();
	}else{
		header('Location: ' . $_SERVER['HTTP_REFERER'],true, 302);
		die();
	}
	
	
	
}


function marcar_tweet_inexistente(){


	global $conn;
	


	$id = $_GET['id'];
	$session_id = $_GET['session_id'];
	$subcateg_manual = 'Tweet_Inexistente';
	$dataLocal = date('Y/m/d H:i:s', time());	
	
	openConnection(); 

	$sql = "update dataset_tweets_base_2021_timeline_30dias_gov_origens_tweets_m set sent_manual_subcateg=?, avaliador=?, updated_at=?  where id=?"; 	 	
	$stmt = $conn->prepare($sql);
	$stmt->bind_param("ssss", $subcateg_manual, $session_id, $dataLocal, $id);
	if ($stmt->execute() === FALSE) {
		throw new Exception("Erro ao salvar alteração: " . $sql . "<br>" . $conn->error);
	}
	
    $stmt->close();		
	closeConnection(); 
	

	
	
}


function buscarListaSorteada(){
	
	global $conn;
	openConnection();
	
	$rows=array();

	$sql = "SELECT id from dataset_tweets_base_2021_timeline_30dias_gov_origens_tweets_m where sent_manual_subcateg is null order BY RAND() limit 1 ";


	foreach ( $conn->query($sql) as $row ) {
		$rows[]= $row;
	}

	$conn->close();		
	
	if (count($rows) == 0){
		print("Pesquisa concluída. Não existem mais tweets a serem classificados!");
		exit();
	}
	
	return $rows; 
	
}


function salvarEmail(){
	
	echo "ok";
 $email = $_GET['email'];
 $myfile = file_put_contents('emails.txt', $email.PHP_EOL, FILE_APPEND | LOCK_EX); 
	
}

function dadosGrafico(){
	
	global $conn;
	openConnection();
	
	$rows=array();

	$sql = "select sent_manual_subcateg categ, COUNT(*) qtd from dataset_tweets_base_2021_timeline_30dias_gov_origens_tweets_m where (sent_manual_subcateg like 'Neg%' or sent_manual_subcateg like 'Pos%' or sent_manual_subcateg like 'Neu%') group by 1";


	foreach ( $conn->query($sql) as $row ) {
		$rows[]= $row;
	}

	$conn->close();		
	
	return $rows; 
	
}


function buscarTodas(){ 
	
	global $conn;
	openConnection();
	
	$rows=array(); 

	$sql = "SELECT id,  avaliador, updated_at, flag, texto_original, sent_vader_subcateg, sent_manual_subcateg from dataset_tweets_base_2021_timeline_30dias_gov_origens_tweets_m where sent_subcateg_manual is not null order by updated_at";


	foreach ( $conn->query($sql) as $row ) {
		$rows[]= $row;
	}
	

	$conn->close();		
	
	return $rows; 
	
}



function resetar(){

	global $conn;
	
	openConnection(); 

	$sql = "update dataset_tweets_base_2021_timeline_30dias_gov_origens_tweets_m set sent_manual_subcateg=null, avaliador=null, updated_at=null "; 	 	
	$stmt = $conn->prepare($sql);
	if ($stmt->execute() === FALSE) {
		throw new Exception("Erro ao salvar alteração: " . $sql . "<br>" . $conn->error);
	}
	
    $stmt->close();		
	closeConnection(); 
	
	header('Location: relatorio.php');	 
	die();
	
	
	
}



?>
